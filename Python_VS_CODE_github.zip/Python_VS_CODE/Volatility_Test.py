import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import pandas_datareader as pdr
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
import talib
import seaborn as sns
from statsmodels.tsa.stattools import adfuller
import statsmodels.api as sm  
from nsetools import Nse 
import datetime 
from datetime import datetime, timedelta

# tick_data=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Intraday 1 Min Data\usdinr.csv",parse_dates=True, index_col=0)

tick_data_1=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Intraday 1 Min Data\bank_nifty_2018_20.csv",parse_dates=True, index_col=0)
tick_data_2=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Intraday 1 Min Data\bank_nifty_2013_16.csv",parse_dates=True, index_col=0)
tick_data_3=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Intraday 1 Min Data\bank_nifty_2010_12.csv",parse_dates=True, index_col=0)

tick_data=pd.concat([tick_data_3, tick_data_2, tick_data_1])
tick_data_test=tick_data[['Date','Time','Close']]
# print(tick_data_test)

date_data=tick_data_test['Date'].unique()
# print(date_data)

minute_vol=[]
intraday_vol=[]

for i in range(len(date_data)):

    live_data=tick_data_test.copy()
    live_data=live_data.set_index('Date')
    live_data =live_data.loc[date_data[i]]
    live_data['prev_close']=live_data['Close'].shift(1)
    live_data['diff'] = live_data['Close'].sub(live_data['prev_close'])

    vol_num= live_data['diff'].std()
    # print(vol_num)
    minute_vol.append(vol_num)

    day_vol_num = vol_num*np.sqrt(len(live_data))
    # print(day_vol_num)
    intraday_vol.append(day_vol_num)


date_data=pd.DataFrame(date_data)
minute_vol=pd.DataFrame(minute_vol)
intraday_vol=pd.DataFrame(intraday_vol)

vol_data=pd.concat([date_data, minute_vol, intraday_vol], axis=1)
vol_data.columns=['date', 'minute_vol', 'intraday_vol']
print(vol_data)

def vol_analysis(day):
    
    vol_data['minute_vol'] = vol_data['minute_vol'].rolling(window=day).std()
    vol_data['day_vol'] = vol_data['intraday_vol'].rolling(window=day).std()

    vol_data['avg_rolling_minute_vol'] = vol_data['minute_vol'].rolling(window=day).mean()
    vol_data['avg_rolling_daily_vol'] = vol_data['day_vol'].rolling(window=day).mean()

    plt.plot(vol_data['minute_vol'])
    plt.title(f'minute_vol of {day} days')
    plt.show()

    plt.plot(vol_data['day_vol'])
    plt.title(f'day_vol of {day} days')
    plt.show()

    plt.plot(vol_data['avg_rolling_minute_vol'])
    plt.title(f'avg_rolling_minute_vol of {day} days')
    plt.show()  

    plt.plot(vol_data['avg_rolling_daily_vol'])
    plt.title(f'avg_rolling_daily_vol of {day} days')
    plt.show()

    return

vol_analysis(30)