import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import pandas_datareader as pdr
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
# import talib
import seaborn as sns
from statsmodels.tsa.stattools import adfuller
import statsmodels.api as sm  
from nsetools import Nse 
import datetime 
from datetime import datetime, timedelta
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
from sklearn import preprocessing
from sklearn.neighbors import KNeighborsClassifier
from sklearn import metrics
import glob
from scipy import stats


# path =r'C:\Users\DeepakShenoy\Desktop\Quantitative Research\glob_files\nifty'
# filenames = glob.glob(path + "/*.csv")

# dfs = []
# for filename in filenames:
#     dfs.append(pd.read_csv(filename))

# big_frame = pd.concat(dfs, ignore_index=True)

# date_list = big_frame['Date'].unique() 

# # print(date_list)

# for i in range(len(date_list)):

#     if i ==0:
        
#         one_day=big_frame.copy()
#         one_day=big_frame.loc[big_frame['Date']==date_list[i]]
#         one_day= one_day['Close']

#         data_stat= one_day.describe()
#         data_stat=pd.DataFrame(data_stat)
#         data_stat['Label'] = data_stat.index
#         data_stat= data_stat[['Label' ,  'Close']]
#         data_stat=data_stat.reset_index(drop=True)

#         first_stat=data_stat.T

#     else:

#         one_day=big_frame.copy()
#         one_day=big_frame.loc[big_frame['Date']==date_list[i]]
#         one_day= one_day['Close']

#         second_stat= one_day.describe()
#         second_stat=pd.DataFrame(second_stat)
#         second_stat['Label'] = data_stat.index
#         second_stat= second_stat[['Label' ,  'Close']]
#         second_stat=second_stat.reset_index(drop=True)
 
#         second_stat=second_stat.T
#         result  = pd.concat([first_stat,second_stat])

#         first_stat=result


# # print(result.loc['Close'])

# distribution_df= result.loc['Close']
# distribution_df=pd.DataFrame(distribution_df)
# distribution_df.columns= ['count', 'mean', 'std', 'min',  '25%', ' 50% ' , ' 75%',  'max']
# distribution_df = distribution_df[['mean', 'std', 'min',  '25%', ' 50% ' , ' 75%',  'max']]
# distribution_df=distribution_df.reset_index(drop=True)


# date_df= pd.DataFrame(date_list)

# distribution_df['Date'] = date_df

# print(distribution_df)

# distribution_df.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\distribution_df.csv")

df=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\distribution_df.csv",parse_dates=True, index_col=0)
df=df[['Date', 'mean', 'std', 'min', 'twenty_five', 'fifty', 'seventy_five', 'max']]
# print(df)

path =r'C:\Users\DeepakShenoy\Desktop\Quantitative Research\glob_files\nifty'
filenames = glob.glob(path + "/*.csv")

dfs = []
for filename in filenames:
    dfs.append(pd.read_csv(filename))

big_frame = pd.concat(dfs, ignore_index=True)

big_frame=big_frame[['Date', 'Time','Close']]

date_list = df['Date'].unique() 

first_quartile_list = []
second_quartile_list = []
third_quartile_list = []
fourth_quartile_list =[]

for i in range(len(date_list)-1):

    new_df=big_frame.copy()
    new_df = new_df.loc [ new_df['Date'] == date_list[i]]
    # print(new_df)

    min_stat = df.copy()
    min_stat= min_stat.loc[ min_stat['Date'] == date_list[i]]
    
    min_var = float(min_stat['min'])
    twenty_fifth_var = float(min_stat['twenty_five'])
    fifty_var = float(min_stat['fifty'])
    seventy_five_var = float(min_stat['seventy_five']) 
    max_var = float(min_stat['max'])

    first_quartile = 0
    second_quartile = 0
    third_quartile = 0
    fourth_quartile =0

    for j in range(len(new_df)):

        if (new_df['Close'].iloc[j] >= min_var) and  (new_df['Close'].iloc[j] <= twenty_fifth_var):

            first_quartile=first_quartile+1

        elif (new_df['Close'].iloc[j] >= twenty_fifth_var) and  (new_df['Close'].iloc[j] <= fifty_var):

            second_quartile=second_quartile+1

        elif (new_df['Close'].iloc[j] >= fifty_var) and  (new_df['Close'].iloc[j] <= seventy_five_var):

            third_quartile=third_quartile+1

        elif new_df['Close'].iloc[j] >= seventy_five_var and  new_df['Close'].iloc[j] <= max_var:

            fourth_quartile=fourth_quartile+1


    first_quartile_list.append(first_quartile)
    second_quartile_list.append(second_quartile)
    third_quartile_list.append(third_quartile)
    fourth_quartile_list.append(fourth_quartile_list)


first_quartile_list=pd.DataFrame(first_quartile_list)
second_quartile_list =pd.DataFrame(second_quartile_list)
third_quartile_list = pd.DataFrame(third_quartile_list)
fourth_quartile_list = pd.DataFrame(fourth_quartile_list)
date_df= pd.DataFrame(date_list)


final_df= pd.concat([date_df, first_quartile_list, second_quartile_list, third_quartile_list], axis=1)
final_df.columns= ['Date','first_quartile_minute', 'second_quartile_minute', 'third_quartile_time']
print(final_df)

# final_df.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\distribution_df_quartile.csv")












