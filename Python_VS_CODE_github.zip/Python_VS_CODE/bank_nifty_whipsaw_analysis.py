import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import pandas_datareader as pdr
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
# import talib
import seaborn as sns
from statsmodels.tsa.stattools import adfuller
import statsmodels.api as sm  
from nsetools import Nse 
import datetime 
from datetime import datetime, timedelta
import time
import threading
from time import perf_counter
import concurrent.futures
import multiprocessing
from dateutil.relativedelta import relativedelta
import datetime 
from datetime import datetime, timedelta
import calendar

# tick_data_1=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Intraday 1 Min Data\bank_nifty_2017_20.csv",parse_dates=True, index_col=0)
# tick_data_2=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Intraday 1 Min Data\bank_nifty_2013_16.csv",parse_dates=True, index_col=0)
# tick_data_3=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Intraday 1 Min Data\bank_nifty_2010_12.csv",parse_dates=True, index_col=0)

# tick_data_1=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\nifty20072014.csv",parse_dates=True, index_col=0)
# tick_data_2=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\niftyjundec2020.csv",parse_dates=True, index_col=0)
# # tick_data_3=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\nifty20072014.csv",parse_dates=True, index_col=0)

# tick_data=pd.concat([ tick_data_1, tick_data_2])

# tick_data_test=tick_data_2
# tick_data_test=tick_data_test.reset_index(drop=True)
# print(tick_data_test)

# tick_data_test=tick_data_test[['Date','Time','Close']]
# tick_data_test['Date'] =pd.to_datetime(tick_data_test['Date'])
# tick_data_test=tick_data_test.dropna()

# tick_data_test['weekday_name']=0

# for i in range(len(tick_data_test)):
    
#     tick_data_test['weekday_name'].iloc[i]=tick_data_test['Date'].iloc[i].strftime("%A")

# print(tick_data_test)

# tick_data_test.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\nifty_whipsaw_day_jundec2020.csv")


tick_data_test=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Intraday 1 Min Data\nifty2020.csv",parse_dates=True, index_col=0)
# print(tick_data_test)

tick_data_close=tick_data_test[['Date','Time','Close','weekday_name']]

# # condition =tick_data_close['weekday_name'] == 'Thursday'
# # tick_data_close_new=tick_data_close[condition]

tick_data_close_new=tick_data_close

print(tick_data_close_new)

date_date=tick_data_close_new['Date'].unique()
print(len(date_date))

whipsaw_stat_1=[]
whipsaw_stat_2=[]
whipsaw_stat_3=[]
whipsaw_stat_4=[]

whipsaw_data_1=[]
whipsaw_data_2=[]
whipsaw_data_3=[]
whipsaw_data_4=[]

date_array=[]

def whipsaw_data(day):
    
    for n in range(day):
        tick_data_test_test=tick_data_test.loc[tick_data_test['Date']==date_date[n]]
        date_num=date_array.append(date_date[n])

        data_1=125
        data_2=250
        data_3=len(tick_data_test_test)-2

        high_1=tick_data_test_test['Close'][0:data_1].max()
        low_1=tick_data_test_test['Close'][0:data_1].min()

        high_2=tick_data_test_test['Close'][data_1:data_2].max()
        low_2=tick_data_test_test['Close'][data_1:data_2].min()

        high_3=tick_data_test_test['Close'][data_2:data_3].max()
        low_3=tick_data_test_test['Close'][data_2:data_3].min()

    ##########################################################################
        if(high_2>high_1):

            whipsaw_stat_1.append("HH_1")
            diff=high_2-high_1
            whipsaw_data_1.append(diff)

        else:
            whipsaw_stat_1.append("NHH_1")
            whipsaw_data_1.append(0)

        if(high_3>high_2):

            whipsaw_stat_2.append("HH_2")
            diff=high_3-high_2
            whipsaw_data_2.append(diff)

        else:
            whipsaw_stat_2.append("NHH_2")
            whipsaw_data_2.append(0)

      ################################################################################    

        if(low_1>low_2):
            whipsaw_stat_3.append("LL_1")
            diff=low_1-low_2
            whipsaw_data_3.append(diff)

        else:
            whipsaw_stat_3.append("NLL_1")
            whipsaw_data_3.append(0)

        if(low_2>low_3):
            whipsaw_stat_4.append("LL_2")
            diff=low_2-low_3
            whipsaw_data_4.append(diff)

        else:
            whipsaw_stat_4.append("NLL_2")
            whipsaw_data_4.append(0)

 
whipsaw_data(len(date_date))
    
date_array=pd.DataFrame(date_array)        
whipsaw_stat_1 =pd.DataFrame(whipsaw_stat_1)
whipsaw_stat_2 =pd.DataFrame(whipsaw_stat_2)
whipsaw_stat_3 =pd.DataFrame(whipsaw_stat_3)
whipsaw_stat_4 =pd.DataFrame(whipsaw_stat_4)

whipsaw_stat=pd.concat([date_array,whipsaw_stat_1,whipsaw_stat_3,whipsaw_stat_2,whipsaw_stat_4], axis=1)
whipsaw_stat.columns=('date','first_period_high_breach','first_period_low_breach','second_period_high_breach','second_period_low_breach')
whipsaw_stat['rank']=whipsaw_stat.sum(axis=1)
print(whipsaw_stat)

date_array=pd.DataFrame(date_array)        
whipsaw_data_1 =pd.DataFrame(whipsaw_data_1)
whipsaw_data_2 =pd.DataFrame(whipsaw_data_2)
whipsaw_data_3 =pd.DataFrame(whipsaw_data_3)
whipsaw_data_4 =pd.DataFrame(whipsaw_data_4)

whipsaw_data=pd.concat([date_array,whipsaw_data_1,whipsaw_data_3,whipsaw_data_2,whipsaw_data_4], axis=1)
whipsaw_data.columns=('date','first_period_high_breach','first_period_low_breach','second_period_high_breach','second_period_low_breach')
# print(whipsaw_data)

whipsaw_stat['combination']=0
# whipsaw_stat['combination']=0

for i in range(len(whipsaw_stat)):
    
    whipsaw_stat['combination'].iloc[i] ={ whipsaw_stat['first_period_high_breach'].iloc[i], whipsaw_stat['first_period_low_breach'].iloc[i],
                   whipsaw_stat['second_period_high_breach'].iloc[i], whipsaw_stat['second_period_low_breach'].iloc[i] }

whipsaw_stat=whipsaw_stat[['date', 'combination']]
print(whipsaw_stat)

# whipsaw_stat.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Equity_Strategy_Backtest\whipsaw_stat_nifty_2020.csv")
# print(len(date_date))
# print(whipsaw_stat['combination'].value_counts())





