from datetime import datetime, timedelta
from kiteconnect import KiteConnect


api_key ='ojo4lqk3v7t7yac7'
api_secret ='2y5tsxsxodjalgxg2x3noskurdoldk47'
# request_token='yrao1oWkw3WD4vPkB6fZg3fpPihs0bfh'
access_token ='KEVnR3si7MWHR7WnGjFK65DiDz5jksBJ'

kite = KiteConnect(api_key=api_key)
# data =kite.generate_session(request_token, api_secret=api_secret)
kite.set_access_token(access_token)
# print(data)
print(f"Logging successful {kite.orders()}")

