import pandas as pd  
import numpy as np  
import pandas_datareader as pdr
import matplotlib.pyplot as plt  
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
import seaborn as sns  
from nsetools import Nse 
import datetime 
from datetime import datetime, timedelta
import time
import threading
from time import perf_counter
import concurrent.futures
import multiprocessing

df=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Equity_Strategy_Backtest\NIFTY_BANK_CHASE_RETURNS.csv",parse_dates=True, index_col=0)
print(df)

df=df.reset_index(drop=True)
plt.plot(df['margin'])
plt.show()

window = 1_00_000

Roll_Max_portfolio = df['margin'].rolling(window, min_periods=1).max()
Daily_Drawdown_portfolio = (df['margin']/Roll_Max_portfolio - 1)*100

plt.plot(Daily_Drawdown_portfolio, color="black", label="PORTFOLIO")
plt.title("DRAWDOWN")
plt.legend()
plt.show()

# df['long_mtm'] = 0

# for i in range(len(df)):

#     if df['LONG_POSITION'].iloc[i] =='LIVE':

#         df['long_mtm'].iloc[i] = ((df['Close'].iloc[i] - df['Close'].iloc[i-1])*25) 

#     else:
        
#         df['long_mtm'].iloc[i] = 0


# df['short_mtm'] = 0


# for i in range(len(df)):

#     if df['SHORT_POSITION'].iloc[i] =='LIVE':

#         df['short_mtm'].iloc[i] = ((df['Close'].iloc[i] - df['Close'].iloc[i-1])*25)*(-1)

#     else:
        
#         df['short_mtm'].iloc[i] = 0


# print(df['long_mtm'].sum(axis=0))

# print(df['short_mtm'].sum(axis=0))

# df['MTM'] = df['long_mtm'] + df['short_mtm'] 

# df['margin'] = 0

# for i in range(len(df)):

#     if i ==0:

#         df['margin'].iloc[i] =2_00_000

#     else:

#         df['margin'].iloc[i] = df['margin'].iloc[i-1] + df['MTM'].iloc[i]


# plt.plot(df['margin'])
# plt.show()

# df.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Equity_Strategy_Backtest\NIFTY_BANK_CHASE_RETURNS.csv")








