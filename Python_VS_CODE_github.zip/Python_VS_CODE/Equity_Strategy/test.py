import pandas as pd  
import numpy as np  
import pandas_datareader as pdr
import matplotlib.pyplot as plt  
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
import seaborn as sns  
from nsetools import Nse 
import datetime 
from datetime import datetime, timedelta

# def data_yahoo():

#     x=pdr.get_data_yahoo('^NSEI', start=datetime(2005, 1, 1), end=datetime.today())

#     return x

# if __name__ == "__main__":
#     print(data_yahoo())


print("Hello")