import pandas as pd  
import numpy as np  
import pandas_datareader as pdr
import matplotlib.pyplot as plt  
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
import seaborn as sns  
from nsetools import Nse 
import datetime as dt
from datetime import datetime
from datetime import timedelta


# tick_data_3=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Intraday 1 Min Data\bank_nifty_2017_20.csv") 
# tick_data_3=tick_data_3.iloc[:93165]
# tick_data_chase_test=tick_data_3
# tick_data_chase_test=tick_data_chase_test.reset_index(drop=True)
# tick_data_chase_test=tick_data_chase_test[['Date' ,'Time','Close']]
# tick_data_chase_test['avg']=tick_data_chase_test['Close'].rolling(window=2400).mean()

# date_df=tick_data_chase_test['Date'].unique()
# tick_data_chase_test['signal']=np.where(tick_data_chase_test['Close'] > tick_data_chase_test['avg'], 1 ,-1)
# tick_data_chase_test['avg']=tick_data_chase_test['avg'].replace(np.nan, 0)

# df=tick_data_chase_test.copy()

# df.loc[(df['Time'] == '10:15') | (df['Time'] == '11:15') | (df['Time'] == '12:15') |
# (df['Time'] == '13:15') | (df['Time'] == '14:15') | (df['Time'] == '15:15'),  'time_signal'] =1

# df['time_signal'] =df['time_signal'].replace(np.nan,0)

# df['max']= 0
# df['min'] = 0

# i=0
# j=0
# n=0

# date_df=df['Date'].unique()
# print(len(date_df))

# for m in range(245):
    
#     test = df.copy()
#     test = df.loc[df['Date'] == date_df[m]]

#     j=len(test) + j 

#     for i in range(i, j + len(test)):
        
#         day_max = df['Close'].iloc[n:i].max()
#         df['max'].iloc[i] = day_max
        
#         day_min = df['Close'].iloc[n:i].min()
#         df['min'].iloc[i] = day_min

#     i = j
#     j = j 
#     n= j
#     print(date_df[m])
   
# df.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\chase_df.csv")
# print(df)

df=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\chase_df.csv",parse_dates=True,index_col=0)
df=df.iloc[:92409]

df['max'] =df['max'].replace(np.nan, 0)
df['min'] =df['min'].replace(np.nan, 0)

condition =df['Time'] != '09:08'
df=df[condition]

df['Time'] = df['Time'].apply(lambda x: datetime.strptime(x, '%H:%M'))
df=df[[ 'Date', 'Time', 'Close', 'signal' , 'max', 'min']]
df['Time']=df['Time'].dt.time

df['long_singal'] = 0

for i in range(10_000):

    if df['signal'].iloc[i] == 1 and df['Close'].iloc[i] > df['max'].iloc[i]:

        if (df['Time'].iloc[i] > '10:15:00'  and  df['Time'].iloc[i] < '11:15:00'):

            df['long_singal'].iloc[i] = 1
        
        else: 

            df['long_singal'].iloc[i] = 0

    else:

        df['long_singal'].iloc[i] = 0


print(df)
# print(df[df['long_singal'] == 1])
# print(df['Time'].iloc[1] < 1900-01-01 09:18:00'  )







# df.loc[ (df['signal'] ==1) & (df['Close'] > df['max']), 'long_signal'] =1
# df.loc[ (df['signal'] ==-1) & (df['Close'] < df['min']), 'short_signal'] = -1 

# df['long_signal'] =df['long_signal'].replace(np.nan, 0)
# df['short_signal'] =df['short_signal'].replace(np.nan, 0)
# df['trade_signal'] =df['long_signal'] + df['short_signal']

# df=df[['Date', 'Time' , 'Close', 'trade_signal']]

