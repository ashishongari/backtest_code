import pandas as pd  
import numpy as np  
import pandas_datareader as pdr
import matplotlib.pyplot as plt  
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
import seaborn as sns  
from nsetools import Nse 
import datetime 
from datetime import datetime, timedelta

# tick_data_chase=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Equity_Strategy_Backtest\tick_data_chase.csv",parse_dates=True, index_col=0)
# date_df=tick_data_chase['Date'].unique()

# signal=[]
# time_frame=[]
# Close=[]
# Date=[]
# Time=[]
# avg=[]
# max_df=[]
# min_df=[]
# z_signal_buy_entry=[]
# z_signal_sell_entry=[]

# for i in range(len(date_df) - 1):

#     tick_data_chase_test=tick_data_chase.copy()
#     tick_data_chase_test=tick_data_chase_test.loc[ tick_data_chase_test['Date'] ==date_df[i]]
    
#     tick_data_chase_test['max']=0
#     tick_data_chase_test['min']=0

#     for i in range(len(tick_data_chase_test)):
        
#         day_max = tick_data_chase_test['Close'].iloc[:i].max()
#         tick_data_chase_test['max'].iloc[i] = day_max
        
#         day_min = tick_data_chase_test['Close'].iloc[:i].min()
#         tick_data_chase_test['min'].iloc[i] = day_min
        

#     for i in range(len(tick_data_chase_test)):

#         signal.append(tick_data_chase_test['signal'].iloc[i])
#         time_frame.append(tick_data_chase_test['time_frame'].iloc[i])
#         Close.append(tick_data_chase_test['Close'].iloc[i])
#         Date.append(tick_data_chase_test['Date'].iloc[i])
#         Time.append(tick_data_chase_test['Time'].iloc[i])
#         avg.append(tick_data_chase_test['avg'].iloc[i])
#         max_df.append(tick_data_chase_test['max'].iloc[i])
#         min_df.append(tick_data_chase_test['min'].iloc[i])
#         z_signal_buy_entry.append(tick_data_chase_test['z_signal_buy_entry'].iloc[i])
#         z_signal_sell_entry.append(tick_data_chase_test['z_signal_sell_entry'].iloc[i])


# signal=pd.DataFrame(signal)
# time_frame=pd.DataFrame(time_frame)
# Close=pd.DataFrame(Close)
# Date=pd.DataFrame(Date)
# Time=pd.DataFrame(Time)
# max_df=pd.DataFrame(max_df)
# min_df=pd.DataFrame(min_df)
# avg=pd.DataFrame(avg)
# z_signal_buy_entry=pd.DataFrame(z_signal_buy_entry)
# z_signal_sell_entry=pd.DataFrame(z_signal_sell_entry)

# df=pd.concat([Date, Time, Close, avg, signal ,time_frame ,max_df, min_df,z_signal_buy_entry, z_signal_sell_entry ], axis=1)
# df.columns= ['Date', 'Time', 'Close', 'avg', 'signal', 'time_frame', 'max','min','z_signal_buy_entry', 'z_signal_sell_entry']
# print(df)

# df.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Equity_Strategy_Backtest\tick_data_chase_analysis.csv")

# tick_data_chase=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Equity_Strategy_Backtest\tick_data_chase_analysis.csv",parse_dates=True, index_col=0)
# # print(tick_data_chase)

# # tick_data_chase['buy_exit_price']=0
# # tick_data_chase['sell_exit_price']=0

# # tick_data_chase['buy_position'] = 0
# tick_data_chase['buy_signal'] = 0

# for i in range(len(tick_data_chase)):

#     if (tick_data_chase['signal'].iloc[i] ==1 and tick_data_chase['time_frame'].iloc[i] ==1) and (tick_data_chase['signal'].iloc[i] != tick_data_chase['signal'].iloc[i-1]) :

#         tick_data_chase['buy_signal'].iloc[i] = 1
#     else:
#         tick_data_chase['buy_signal'].iloc[i] = 0

# print(tick_data_chase)

# tick_data_chase.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Equity_Strategy_Backtest\tick_data_chase_test.csv")


for i in range(1,5):
    print(i)