import mysql.connector 

mydb=mysql.connector.connect( host="localhost", user='root', passwd='NITKanu@21', database='grocery_store')

mycursor= mydb.cursor()

# mycursor.execute("show databases")

# for i in mycursor:k
#     print(i)     
    
mycursor.execute("select * from products")

for i in mycursor:
    print(i)    