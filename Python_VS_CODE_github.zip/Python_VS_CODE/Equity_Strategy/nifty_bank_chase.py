import pandas as pd  
import numpy as np  
import pandas_datareader as pdr
import matplotlib.pyplot as plt  
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
import seaborn as sns  
from nsetools import Nse 
import datetime 
from datetime import datetime, timedelta
from datetime import datetime


# def long_side_chase():
    
#     # tick_data_1=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Intraday 1 Min Data\bank_nifty_2010_12.csv",parse_dates=True, index_col=0)
#     # tick_data_2=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Intraday 1 Min Data\bank_nifty_2013_16.csv",parse_dates=True, index_col=0)
#     tick_data_3=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Intraday 1 Min Data\bank_nifty_2017_20.csv",parse_dates=True, index_col=0) 

#     # tick_data_chase_test=pd.concat([ tick_data_1, tick_data_2, tick_data_3])
#     tick_data_chase_test=tick_data_3
#     tick_data_chase_test=tick_data_chase_test.reset_index(drop=True)
#     tick_data_chase_test=tick_data_chase_test[['Date', 'Time','Close']]
#     tick_data_chase_test['avg']=tick_data_chase_test['Close'].rolling(window=2400).mean()

#     date_df=tick_data_chase_test['Date'].unique()
#     tick_data_chase_test['signal']=np.where(tick_data_chase_test['Close'] > tick_data_chase_test['avg'], 1 ,-1)

#     tick_data_chase_test=tick_data_chase_test.dropna()
#     tick_data_chase_test=tick_data_chase_test.reset_index(drop=True)
#     date_df=tick_data_chase_test['Date'].unique()

#     tick_data_chase_test['time_signal']= 0
#     tick_data_chase_test['max']= 0
#     tick_data_chase_test['min'] = 0

#     tick_data_chase_test['long_streak'] =0
#     tick_data_chase_test['long_exit_price'] = 0

#     i=0
#     j=0
#     n=0

#     ########################################################################################

#     for m in range(len(date_df)-1):

#         test = tick_data_chase_test.copy()
#         test = tick_data_chase_test.loc[tick_data_chase_test['Date'] == date_df[m]]
    
#         j=len(test) + j 

#         for i in range(i, j + len(test)):

#             day_max = tick_data_chase_test['Close'].iloc[n:i].max()
#             tick_data_chase_test['max'].iloc[i] = day_max
            
#             day_min = tick_data_chase_test['Close'].iloc[n:i].min()
#             tick_data_chase_test['min'].iloc[i] = day_min

#         i = j
#         j = j 
#         n= j

#     # ################################################################################

#     for i in range(len(tick_data_chase_test)):

#         if tick_data_chase_test['Time'].iloc[i] =='10:15':

#             tick_data_chase_test['time_signal'].iloc[i] =1

#         elif tick_data_chase_test['Time'].iloc[i] =='11:15':

#             tick_data_chase_test['time_signal'].iloc[i] =1

#         elif tick_data_chase_test['Time'].iloc[i] =='12:15':

#             tick_data_chase_test['time_signal'].iloc[i] =1

#         elif tick_data_chase_test['Time'].iloc[i] =='13:15':

#             tick_data_chase_test['time_signal'].iloc[i] =1

#         elif tick_data_chase_test['Time'].iloc[i] =='14:15':

#             tick_data_chase_test['time_signal'].iloc[i] =1

#         elif tick_data_chase_test['Time'].iloc[i] =='15:15':

#             tick_data_chase_test['time_signal'].iloc[i] =1

#         else: 

#             tick_data_chase_test['time_signal'].iloc[i] =0

#     #######################################################################################

#     for i in range(1,len(tick_data_chase_test)):

#         if tick_data_chase_test['signal'].iloc[i] == 1 and  (tick_data_chase_test['Date'].iloc[i] == tick_data_chase_test['Date'].iloc[i-1]) : 

#             tick_data_chase_test['long_streak'].iloc[i] =tick_data_chase_test['long_streak'].iloc[i-1]

#         elif (tick_data_chase_test['signal'].iloc[i] == 1  and tick_data_chase_test['signal'].iloc[i-1] == 1)  and  tick_data_chase_test['Date'].iloc[i] != tick_data_chase_test['Date'].iloc[i-1] : 

#             tick_data_chase_test['long_streak'].iloc[i] =tick_data_chase_test['long_streak'].iloc[i-1] + 1

#         else:

#             tick_data_chase_test['long_streak'].iloc[i]=0

#     ###############################################################################

#     for i in range(1,len(tick_data_chase_test)):

#         if (tick_data_chase_test['long_streak'].iloc[i] ==0) and (tick_data_chase_test['signal'].iloc[i] == 1 and tick_data_chase_test['signal'].iloc[i-1] == 1) :

#             tick_data_chase_test['long_exit_price'].iloc[i] = min(tick_data_chase_test['min'].iloc[i], tick_data_chase_test['avg'].iloc[i])

#         elif (tick_data_chase_test['long_streak'].iloc[i] ==1) and (tick_data_chase_test['signal'].iloc[i] == 1 and tick_data_chase_test['signal'].iloc[i-1] == 1) :

#             tick_data_chase_test['long_exit_price'].iloc[i] = min(tick_data_chase_test['min'].iloc[i], tick_data_chase_test['avg'].iloc[i])
            
#         elif tick_data_chase_test['long_streak'].iloc[i] >1 :

#             tick_data_chase_test['long_exit_price'].iloc[i] = tick_data_chase_test['avg'].iloc[i]

#         else:

#             tick_data_chase_test['long_exit_price'].iloc[i] = 0

#     ##################################################################################

#     tick_data_chase_test['long_exit_price'] =tick_data_chase_test['long_exit_price'].shift(1)

#     tick_data_chase_test['long_exit_price'].replace(r'^\s*$', np.nan, regex=True)
#     tick_data_chase_test['long_exit_price'] =tick_data_chase_test['long_exit_price'].ffill()

#     tick_data_chase_test['long_entry_signal'] = np.where( tick_data_chase_test['signal'] ==1, 1 ,0)
#     tick_data_chase_test['long_exit_signal'] = np.where( tick_data_chase_test['Close'] <  tick_data_chase_test['long_exit_price'], 1 ,0)

#     tick_data_chase_test['buy_position']=0

#     ################################################################################

#     for i in range(1,len(tick_data_chase_test)):
        
#         if (tick_data_chase_test['long_entry_signal'].iloc[i] == 0 and tick_data_chase_test['long_exit_signal'].iloc[i] == 1) and (tick_data_chase_test['buy_position'].iloc[i-1] =='postion_live') :
            
#             tick_data_chase_test['buy_position'].iloc[i]='no_position'
            
#         elif ((tick_data_chase_test['long_entry_signal'].iloc[i] == 1 and tick_data_chase_test['long_exit_signal'].iloc[i] ==0) or (tick_data_chase_test['buy_position'].iloc[i-1] =='postion_live')) and (tick_data_chase_test['long_exit_price'].iloc[i] > 0):
            
#             tick_data_chase_test['buy_position'].iloc[i]='postion_live'
                
#         else :
            
#             tick_data_chase_test['buy_position'].iloc[i]='no_position'

#     ###################################################################################################

#     tick_data_chase_test['new_signal'] = np.where( tick_data_chase_test['long_exit_price'] > 0, 1 , 0 )

#     tick_data_chase_test['LONG_POSITION']=0

#     for i in range(len(tick_data_chase_test)):

#         if tick_data_chase_test['time_signal'].iloc[i] ==1 and (tick_data_chase_test['new_signal'].iloc[i] ==1 and tick_data_chase_test['new_signal'].iloc[i-1] ==1) and (tick_data_chase_test['buy_position'].iloc[i] =='postion_live'):
            
#             tick_data_chase_test['LONG_POSITION'].iloc[i] = 'LIVE'
        
#         elif tick_data_chase_test['LONG_POSITION'].iloc[i-1] == 'LIVE' and  (tick_data_chase_test['new_signal'].iloc[i] ==1 and tick_data_chase_test['new_signal'].iloc[i-1] ==1) and (tick_data_chase_test['buy_position'].iloc[i] =='postion_live'):

#             tick_data_chase_test['LONG_POSITION'].iloc[i] = 'LIVE'

#         else :

#             tick_data_chase_test['LONG_POSITION'].iloc[i]='NO'

#     #########################################################################################
        
#     tick_data_chase_test.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Equity_Strategy_Backtest\tick_data_chase_long_2017_20.csv")

#     print(tick_data_chase_test)

#     return 

# long_side_chase()   
