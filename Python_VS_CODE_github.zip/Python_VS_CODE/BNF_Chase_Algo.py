import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import pandas_datareader as pdr
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
# import talib
import seaborn as sns
from statsmodels.tsa.stattools import adfuller
import statsmodels.api as sm  
from nsetools import Nse 
import datetime 
from datetime import datetime, timedelta
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
from sklearn import preprocessing
from sklearn.neighbors import KNeighborsClassifier
from sklearn import metrics
import glob

path =r'C:\Users\DeepakShenoy\Desktop\Quantitative Research\glob_files\nifty_bank'
filenames = glob.glob(path + "/*.csv")

dfs = []
for filename in filenames:
    dfs.append(pd.read_csv(filename))

big_frame = pd.concat(dfs, ignore_index=True)

big_frame=big_frame[['Date', 'Time', 'Close']]

big_frame['EMA'] =big_frame['Close'].ewm(span=3000,adjust=False).mean()

####################################################
big_frame=big_frame.iloc[:10_000]##########
####################################################

# 992233

big_frame=big_frame.reset_index(drop=True)

# print(big_frame)

date_list= big_frame['Date'].unique()

# print(date_list)

for i in range(len(date_list)):

    new_frame=big_frame.copy()
    new_frame= new_frame.loc[ new_frame['Date'] == date_list[i]]

    new_frame['High'] =0
    new_frame['Low'] = 0

    for j in range(len(new_frame)):

        new_frame['High'].iloc[j] = new_frame['Close'].iloc[:j].max()
        new_frame['Low'].iloc[j] = new_frame['Close'].iloc[:j].min()

    if i ==0:

        first_frame = new_frame

    else:

        result_df= pd.concat( [first_frame, new_frame ])
        first_frame=result_df

new_frame['Close'] = new_frame['Close'].shift(1)

# #################################################################################################################

result_df['EMA_signal'] =np.where( result_df['Close'] > result_df['EMA'], 1 , -1)
result_df.loc[ (result_df['Time'] =='10:15') | (result_df['Time'] =='11:15') | (result_df['Time'] =='12:15') | (result_df['Time'] =='13:15') | (result_df['Time'] =='14:15') | (result_df['Time'] =='15:15'), 'Time_signal'] = 1
result_df['Time_signal'] =result_df['Time_signal'].replace(np.nan, 0)

# ###########################################################################################################################

# """
# Long Position Algo

# """

result_df.loc[(result_df['EMA_signal']  == 1) & (result_df['Time_signal']  == 1) & ( result_df['Close'] >= result_df['High'] ) , 'z_signal_buy_entry'] = 1

result_df['z_signal_buy_entry'] =result_df['z_signal_buy_entry'].replace(np.nan, 0)

result_df['z_signal_buy_entry_new']=0

# result_df.loc[ result_df['z_signal_buy_entry'] ==1, 'z_signal_buy_entry_new'] =1


for i in range(len(result_df) -1 ):

    if result_df['z_signal_buy_entry'].iloc[i] ==1  :

        result_df['z_signal_buy_entry_new'].iloc[i+1]= 1

    elif result_df['z_signal_buy_entry_new'].iloc[i] ==1 and result_df['EMA_signal'].iloc[i] != -1:


         result_df['z_signal_buy_entry_new'].iloc[i+1]= 1

    else:

        result_df['z_signal_buy_entry_new'].iloc[i+1]= 0

result_df['buy_new_streak']=1

for i in range(len(result_df)-1):
    
    if result_df['z_signal_buy_entry_new'].iloc[i] ==1 and result_df['Date'].iloc[i] == result_df['Date'].iloc[i-1]:

        result_df['buy_new_streak'].iloc[i+1] = result_df['buy_new_streak'].iloc[i]

    elif  result_df['buy_new_streak'].iloc[i] >=1  and result_df['z_signal_buy_entry_new'].iloc[i] == 1 and result_df['Date'].iloc[i] != result_df['Date'].iloc[i-1]:

        result_df['buy_new_streak'].iloc[i+1] = result_df['buy_new_streak'].iloc[i] + 1 

result_df['buy_new_streak'] =result_df['buy_new_streak'] - 1

result_df['buy_exit']=0 

for i in range(len(result_df)):

    if result_df['z_signal_buy_entry_new'].iloc[i] ==1 and result_df['buy_new_streak'].iloc[i]==0 and result_df['Close'].iloc[i] >= result_df['Low'].iloc[i]:

        result_df['buy_exit'].iloc[i] =0

    elif result_df['z_signal_buy_entry_new'].iloc[i] ==1 and result_df['buy_new_streak'].iloc[i] > 0 and result_df['EMA_signal'].iloc[i] != 1:

        result_df['buy_exit'].iloc[i] = 1

    else:

        result_df['buy_exit'].iloc[i] =0

result_df['buy_position'] =0

for i in range(len(result_df)):
    
    if (result_df['z_signal_buy_entry'].iloc[i] ==0 and result_df['buy_exit'].iloc[i] ==1) and (result_df['buy_position'].iloc[i-1] =='position_live'):
        
        result_df['buy_position'].iloc[i]='no_position'
        
    elif (result_df['z_signal_buy_entry'].iloc[i] ==1 and result_df['buy_exit'].iloc[i] ==0) or (result_df['buy_position'].iloc[i-1] =='position_live') :
        
         result_df['buy_position'].iloc[i]='position_live'
            
    else :
        
        result_df['buy_position'].iloc[i]='no_position'

result_df['buy_exit_price'] =0

for i in range(len(result_df)):

    if result_df['buy_new_streak'].iloc[i] ==0 and result_df['buy_position'].iloc[i] =='no_position' :

        result_df['buy_exit_price'].iloc[i] = 0

    elif result_df['buy_new_streak'].iloc[i] ==0 and result_df['buy_position'].iloc[i] =='position_live' and result_df['EMA_signal'].iloc[i] ==  1:

        result_df['buy_exit_price'].iloc[i] = result_df['Low'].iloc[i]

    elif  result_df['buy_new_streak'].iloc[i] > 0 and  result_df['buy_position'].iloc[i] =='position_live' and result_df['EMA_signal'].iloc[i] == 1 :

        result_df['buy_exit_price'].iloc[i] = result_df['EMA'].iloc[i]

    elif  result_df['buy_new_streak'].iloc[i] > 0 and result_df['buy_position'].iloc[i] =='position_live'  and result_df['EMA_signal'].iloc[i] == -1 :

        result_df['buy_exit_price'].iloc[i] = result_df['EMA'].iloc[i]

    else:

        result_df['buy_exit_price'].iloc[i] = 0


# result_df['buy_exit_price']= result_df['buy_exit_price'].shift(1)

result_df['long_price_mtm'] =0

for i in range(len(result_df)):

    if result_df['buy_position'].iloc[i] =='position_live':

        result_df['long_price_mtm'].iloc[i] = result_df['Close'].iloc[i]

    else:

        result_df['long_price_mtm'].iloc[i] = 0

result_df['Long_MTM'] = 0

for i in range(len(result_df)):

    if result_df['buy_position'].iloc[i] =='position_live' and  result_df['buy_position'].iloc[i-1] =='position_live' :

        result_df['Long_MTM'].iloc[i] =  result_df['long_price_mtm'].iloc[i] - result_df['long_price_mtm'].iloc[i-1]

    elif result_df['buy_exit'].iloc[i] ==1 and result_df['buy_position'].iloc[i] =='position_live':

        result_df['Long_MTM'].iloc[i]=  result_df['buy_exit_price'].iloc[i] - result_df['long_price_mtm'].iloc[i-1]

    else:

        result_df['Long_MTM'].iloc[i]= 0

# # ###########################################################################################################################

"""
Short Position Algo

"""

result_df.loc[(result_df['EMA_signal']  == -1) & (result_df['Time_signal']  == 1) & ( result_df['Close'] >= result_df['High'] ) , 'z_signal_sell_entry'] = 1

result_df['z_signal_sell_entry'] =result_df['z_signal_sell_entry'].replace(np.nan, 0)

result_df['z_signal_sell_entry_new']=0

for i in range(len(result_df) -1 ):

    if result_df['z_signal_sell_entry'].iloc[i] ==1  :

        result_df['z_signal_sell_entry_new'].iloc[i+1]= 1

    elif result_df['z_signal_sell_entry_new'].iloc[i] ==1 and result_df['EMA_signal'].iloc[i] != 1:


         result_df['z_signal_sell_entry_new'].iloc[i+1]= 1   

    else:

        result_df['z_signal_sell_entry_new'].iloc[i+1]= 0


result_df['sell_new_streak']=1

for i in range(len(result_df)-1):
    
    if result_df['z_signal_sell_entry_new'].iloc[i] ==1 and result_df['Date'].iloc[i] == result_df['Date'].iloc[i-1]:

        result_df['sell_new_streak'].iloc[i+1] = result_df['sell_new_streak'].iloc[i]

    elif  result_df['sell_new_streak'].iloc[i] >=1  and result_df['z_signal_sell_entry_new'].iloc[i] == 1 and result_df['Date'].iloc[i] != result_df['Date'].iloc[i-1]:

        result_df['sell_new_streak'].iloc[i+1] = result_df['sell_new_streak'].iloc[i] + 1 

result_df['sell_new_streak'] =result_df['sell_new_streak'] - 1

result_df['sell_exit']=0 

for i in range(len(result_df)):

    if result_df['z_signal_sell_entry_new'].iloc[i] ==1 and result_df['sell_new_streak'].iloc[i]==0 and result_df['Close'].iloc[i] >= result_df['High'].iloc[i]:

        result_df['sell_exit'].iloc[i] =0

    elif result_df['z_signal_sell_entry_new'].iloc[i] ==1 and result_df['sell_new_streak'].iloc[i] > 0 and result_df['EMA_signal'].iloc[i] != -1:

        result_df['sell_exit'].iloc[i] = 1

    else:

        result_df['sell_exit'].iloc[i] =0

result_df['sell_position'] =0

for i in range(len(result_df)):
    
    if (result_df['z_signal_sell_entry'].iloc[i] ==0 and result_df['sell_exit'].iloc[i] ==1) and (result_df['sell_position'].iloc[i-1] =='position_live'):
        
        result_df['sell_position'].iloc[i]='no_position'
        
    elif (result_df['z_signal_sell_entry'].iloc[i] ==1 and result_df['sell_exit'].iloc[i] ==0) or (result_df['sell_position'].iloc[i-1] =='position_live') :
        
         result_df['sell_position'].iloc[i]='position_live'
            
    else :
        
        result_df['sell_position'].iloc[i]='no_position'

result_df['sell_exit_price'] =0

for i in range(len(result_df)):

    if result_df['sell_new_streak'].iloc[i] ==0 and result_df['sell_position'].iloc[i] =='no_position' :

        result_df['sell_exit_price'].iloc[i] = 0

    elif result_df['sell_new_streak'].iloc[i] ==0 and result_df['sell_position'].iloc[i] =='position_live'  and result_df['EMA_signal'].iloc[i] == -1:

        result_df['sell_exit_price'].iloc[i] = result_df['High'].iloc[i]

    elif  result_df['sell_new_streak'].iloc[i] > 0 and result_df['sell_position'].iloc[i] == 'position_live'  and result_df['EMA_signal'].iloc[i] == -1 :

        result_df['sell_exit_price'].iloc[i] = result_df['EMA'].iloc[i]

    elif  result_df['sell_new_streak'].iloc[i] > 0 and result_df['sell_position'].iloc[i] =='position_live'  and result_df['EMA_signal'].iloc[i] == 1 :

        result_df['sell_exit_price'].iloc[i] = result_df['EMA'].iloc[i]

    else:

        result_df['sell_exit_price'].iloc[i] = 0


result_df['short_price_mtm'] =0

for i in range(len(result_df)):

    if result_df['sell_position'].iloc[i] =='position_live':

        result_df['short_price_mtm'].iloc[i] = result_df['Close'].iloc[i]

    else:

        result_df['short_price_mtm'].iloc[i] = 0


result_df['Short_MTM'] = 0

for i in range(len(result_df)):

    if result_df['sell_position'].iloc[i] =='position_live' and result_df['sell_position'].iloc[i-1] =='position_live':

        result_df['Short_MTM'].iloc[i] =  (result_df['short_price_mtm'].iloc[i] - result_df['short_price_mtm'].iloc[i-1])*(-1)

    elif result_df['sell_exit'].iloc[i] ==1 and result_df['sell_position'].iloc[i] =='position_live':

        result_df['Short_MTM'].iloc[i]=  (result_df['sell_exit_price'].iloc[i] - result_df['short_price_mtm'].iloc[i-1])*(-1)

    else:

        result_df['Short_MTM'].iloc[i]= 0

result_df['Total_MTM'] = result_df['Short_MTM'] + result_df['Long_MTM']

result_df['Total_MTM']= result_df['Total_MTM']*25

result_df['Equity_curve']= 0

for i in range(len(result_df)):

    if i ==0:

        result_df['Equity_curve'].iloc[i] = result_df['Close'].iloc[i]*25

    else:

        result_df['Equity_curve'].iloc[i]= result_df['Equity_curve'].iloc[i-1] + (result_df['Total_MTM'].iloc[i])

print(result_df.iloc[300:350])

plt.plot(result_df['Total_MTM'])
plt.show()

# result_df.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\bnf_50_ema_10.csv")







