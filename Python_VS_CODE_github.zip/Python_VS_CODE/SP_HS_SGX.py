import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import pandas_datareader as pdr
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
# import talib
import seaborn as sns
from statsmodels.tsa.stattools import adfuller
import statsmodels.api as sm  
from nsetools import Nse 
from nsepy.history import get_price_list
from datetime import datetime
from pytz import timezone
from datetime import datetime
from dateutil import tz
from pytz import all_timezones
import glob

# sp_fut=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\sp500_2016_jan_2020_dec.csv", parse_dates=True, index_col=0)

# hang_seng=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\hang_seng_2016_jan_2020_dec.csv", parse_dates=True, index_col=0)

# sp_fut=sp_fut[['Date', 'Close']]
# hang_seng=hang_seng[['Date', 'Close']]

# sp_fut['Date'] =pd.to_datetime(sp_fut['Date'])
# hang_seng['Date'] =pd.to_datetime(hang_seng['Date'])

# print(sp_fut.dtypes)

# merged_df = pd.merge(sp_fut,  hang_seng,  on ='Date',  how ='inner')
# merged_df=merged_df.replace(np.nan, 0)
# merged_df.columns=['DATE','SP500', 'HANG_SENG']
# print(merged_df.dtypes)

# def compare():
#     merged_df['SP500'] = (merged_df['SP500'] / merged_df['SP500'].iloc[0]) *100
#     merged_df['HANG_SENG'] = (merged_df['HANG_SENG'] / merged_df['HANG_SENG'].iloc[0]) *100

#     plt.plot(merged_df['SP500'], label='SP500')
#     plt.plot(merged_df['HANG_SENG'], label='HANG_SENG')
#     plt.legend()
#     plt.show()

# compare()

sgx_nifty=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\sgx_night_data.csv", parse_dates=True)


# sgx_nifty=sgx_nifty[['Date_Time_US','Date_Time_India' ,'Close', 'Open' , 'High', 'Low' ,'Volume']]
# sgx_nifty=sgx_nifty.reset_index(drop=True)

# sgx_nifty['Time'] =sgx_nifty['IST'].dt.time
# # sgx_nifty =sgx_nifty.reset_index(drop=True)
# sgx_nifty['Time']=sgx_nifty['Time'].astype(str)


condition = sgx_nifty['Time'] == '23:00:00'
sgx_nifty=sgx_nifty.loc[condition]
sgx_nifty =sgx_nifty.reset_index(drop=True)
# sgx_nifty=sgx_nifty[['Date_Time_US','Date_Time_India' ,'Date','Time','Close', 'Open' , 'High', 'Low' ,'Volume']]

print(sgx_nifty)

# sgx_nifty.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\SGX_NIGHT_DATA.csv")








