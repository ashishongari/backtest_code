import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import pandas_datareader as pdr
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
# import talib
import seaborn as sns
from statsmodels.tsa.stattools import adfuller
import statsmodels.api as sm  
from nsetools import Nse 
import datetime 
from datetime import datetime, timedelta

class calculator:

    def __init__(self,x ,y):
        self.first=x
        self.second=y

    def add(self):
        return print(f" addition of {self.first} and {self.second} is : {self.first + self.second}")

    def sub(self):
        return print(f" subtraction of {self.first} and {self.second} is : {self.first - self.second}")

    def product(self):
        return print(f" product of {self.first} and {self.second} is : {self.first * self.second}")

    def div(self):

        if self.second ==0:
            return print(f" division of {self.first} and {self.second} is : invalid")
        else:
            return print(f" division of {self.first} and {self.second} is : {self.first/self.second}")

    def change_first(self, first):
        self.first=first

    def change_second(self, second):
        self.second=second


set_1=calculator(20,20)
set_2=calculator(120,420)


class stock:

    def __init__(self, symbol):
        self.symbol=symbol

    def historical_data(self):
        df= get_history(self.symbol, start=date(2010,1,1), end=date.today())['Close']

        return print(df)

stock_1=stock('INFY')
stock_1.historical_data()

class Student:
    def __init__(self, name, age, grade):
        self.name=name
        self.age=age
        self.grade=grade

    def get_grade(self):
        return self.grade


class Course:
    def __init__(self, name, max_students):
        self.name=name
        self.max_students=max_students
        self.students=[]

    def add_student(self, student):

        if len(self.students) < self.max_students:
            self.students.append(student)
            return True
        else:
            return False

    def get_avg_grade(self):
        value=0
        for student in self.students:
            value +=student.get_grade()

        return print(f"avg is {value/len(self.students)}")

s1=Student('Tim',19,95)
s2=Student('Bill',18,75)
s3=Student('Jim',17,65)

course=Course('Science',2)
course.add_student(s1)
course.add_student(s2)
# print(course.students[0].name)
print(course.get_avg_grade()) 

class pet:
    def __init__(self,name, age):
        self.name=name
        self.age=age
    
    def show(self):
        print(f" I am {self.name} and I am {self.age} years old")
    
    def speak(self):
        print("I speak English")

class cat(pet):
    def speak(self):
        print("Meow")

class dog(pet):
    def speak(self):
        print("Bark")

p =pet("Tim", 19)
p.show()

c =pet("Bill", 21)
c.show()

d=dog("jill", 25)
d.speak()


