# Importing libraries
import pandas as pd  
import numpy as np  
import math
import itertools
from matplotlib.ticker import NullFormatter
import matplotlib.ticker as ticker
import matplotlib.pyplot as plt  
import seaborn as seabornInstance 
# %matplotlib inline
import pandas_datareader as pdr
import datetime 
import yfinance as yf
import statsmodels.api as sm
import statistics
import seaborn as sns
from scipy import stats
from scipy.stats import laplace
from scipy.stats import norm
from scipy.stats import kurtosis
import random
from scipy.stats import skew 
import pylab as pl
# from sklearn import tree
# from sklearn import linear_model
# from sklearn import preprocessing
# from sklearn import datasets
# from sklearn.metrics import confusion_matrix
# from sklearn.model_selection import cross_val_predict
# from sklearn.metrics import mean_squared_error, r2_score
# from sklearn.preprocessing import PolynomialFeatures
# from sklearn.model_selection import train_test_split
# from sklearn.neighbors import KNeighborsClassifier
# from sklearn.preprocessing import PolynomialFeatures
# from sklearn.linear_model import LinearRegression
# from sklearn.model_selection import train_test_split 
# from sklearn.linear_model import LogisticRegression
# from sklearn import mixture as mix
# from sklearn import metrics
import operator
from nsepy import get_history
from datetime import date
# from sklearn.model_selection import KFold
import multiprocessing as mp

# tick_data=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\nifty20142017.csv",parse_dates=True, index_col=0)   
# tick_data=tick_data[['Date','Time','Open','High','Low','Close']] 
# tick_data['Date_time']=pd.to_datetime(tick_data['Date'] +' '+ tick_data['Time']) 
# tick_data_test=tick_data[['Date','Time','Date_time','Close']]


tick_data=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\nifty201820.csv",parse_dates=True, index_col=0)
tick_data=tick_data[['Date','Time','Open','High','Low','Close']]
tick_data['Date_time']=pd.to_datetime(tick_data['Date'] +' '+ tick_data['Time'])
tick_data_test=tick_data[['Date','Time','Date_time','Close']]


tick_data_test=tick_data_test.dropna()
print(tick_data_test)

tick_data_close=tick_data_test[['Date','Time','Date_time','Close']]
date_date=tick_data_close['Date'].unique()
print(date_date)

#BACKTETST_LOOP_FINAL

cummulative_return_array_old=[]

for n in range(2):
    
    extra_time = 345 
    otm_range=100
    
    tick_data_close=tick_data_test[['Date','Time','Date_time','Close']]

    date_date=tick_data_close['Date'].unique()
    
    date_date_single=tick_data_close.loc[tick_data_close['Date'] == date_date[n]]
  
    date_date_single=date_date_single[['Date_time','Time','Close']]

    reference_spot=(date_date_single['Close'][0:15]).mean()
    
#     call_iv=iv=vix_data['Close'].iloc[n]
#     put_iv=call_iv*(1.15)

 
    call_iv=random.randrange(15,33)
    put_iv=call_iv*(1.15)
    
    
    """
    
    Middle strike Code
    
    """

    x=round(reference_spot,-2)
    y=x+100
    mid=(x+y)//2
    straddle=[]

    dist_1=abs(reference_spot-x)
    dist_2=abs(reference_spot-y)
    dist_3=abs(reference_spot-mid)

    list_data=[dist_1,dist_2,dist_3]
    data_min=min(list_data)
    
    """
    Strike Selection code
    
    """

    if data_min==dist_1:
        
        straddle.append(x)
    
    elif data_min==dist_2:
        
        straddle.append(y)
    
    else:
        
        straddle.append(mid)
    

    upper_strangle=straddle[0]+otm_range
    lower_strangle=straddle[0]-otm_range

    date_date_single['Straddle']=straddle[0]
    date_date_single['upper_strangle']=upper_strangle
    date_date_single['lower_strangle']=lower_strangle

    date_date_single_day=date_date_single.iloc[15:,:]
    
    """ 
    Intraday time code
    
    """

    time_left=[]

    for i in range(0,len(date_date_single_day)):
        
        time_left.append(len(date_date_single_day)-i)

    
##################################################################################################################

    close=np.array(date_date_single_day['Close'])

    real_time=np.array(date_date_single_day['Time'])

    
    time=np.array(time_left)

    call_price_data_atm=[]
    time_data_call_atm=[]
    
    
    """
     BlackScholes Equation for call_minute_data_atm
    
    """
    
    
    def call_minute_data_atm(k,iv):
        
        T=len(date_date_single_day)
        minute_left=len(date_date_single_day) + extra_time 
        
        """tick data of Call prices"""
        
        for i in range(0,T):
            
            if(T>=0):
                
                minute_left=minute_left-1
                
                t=(minute_left/1400)/365
                time_data_call_atm.append(minute_left)
            
                v=iv*0.01
                d1= (np.log(close[i]/k) + ((0.1 +(v*v*0.5))*t)) / (v*np.sqrt(t))
                d2=d1-(v*np.sqrt(t))
        
                phi=np.exp(-d1*d1*0.5)/np.sqrt(2*np.pi)
    
                callprice= (close[i]*norm.cdf(d1)) - k*norm.cdf(d2)*np.exp(-0.1*t)
                call_price_data_atm.append(callprice)

        return 

    call_minute_data_atm(straddle[0],call_iv)

    call_price_data_atm=pd.DataFrame(call_price_data_atm)
    time_data_call_atm=pd.DataFrame(time_data_call_atm)
    data_hourly_call_atm=pd.concat([time_data_call_atm,call_price_data_atm], axis=1)
    data_hourly_call_atm.columns=['Minutes_left','Call_price_atm']
####################################################################################################################

    """
     BlackScholes Equation for call_minute_data_otm
    
    """


    call_price_data_otm=[]
    time_data_call_otm=[]

    def call_minute_data_otm(k,iv):
        
        T=len(date_date_single_day)
        minute_left=len(date_date_single_day) + extra_time
        
        """tick data of Call prices"""
        
        for i in range(0,T):
            
            T=T-1
            
            if(T>=0):
                
                minute_left=minute_left-1
                
                t=(minute_left/1400)/365
                
                time_data_call_otm.append(minute_left)
                
                v=iv*0.01
                
                d1= (np.log(close[i]/k) + ((0.1 +(v*v*0.5))*t)) / (v*np.sqrt(t))
                d2=d1-(v*np.sqrt(t))
                
                phi=np.exp(-d1*d1*0.5)/np.sqrt(2*np.pi)
                callprice= (close[i]*norm.cdf(d1)) - k*norm.cdf(d2)*np.exp(-0.1*t)
                call_price_data_otm.append(callprice)

        return 

    call_minute_data_otm(upper_strangle,call_iv)

    call_price_data_otm=pd.DataFrame(call_price_data_otm)
    time_data_call_otm=pd.DataFrame(time_data_call_otm)
    data_hourly_call_otm=pd.concat([time_data_call_otm,call_price_data_otm], axis=1)
    data_hourly_call_otm.columns=['Minutes_left','Call_price_otm']
##################################################################################################################


    """
     BlackScholes Equation for put_minute_data_atm
    
    """
    
    
    put_price_data_atm=[]
    time_data_put_atm=[]

    def put_minute_data_atm(k,iv):
        
        T=len(date_date_single_day)
        minute_left=len(date_date_single_day) + extra_time 
        
        """tick data of Call prices"""
        
        for i in range(0,T):
            
            T=T-1
            
            if(T>=0):
                
                minute_left=minute_left-1
                
                t=(minute_left/1400)/365
                
                time_data_put_atm.append(minute_left)
            
                v=iv*0.0115
                d1= (np.log(close[i]/k) + ((0.1 +(v*v*0.5))*t)) / (v*np.sqrt(t))
                d2=d1-(v*np.sqrt(t))
        
    
                putprice= (-close[i]*norm.cdf(-d1)) + k*norm.cdf(-d2)*np.exp(-0.1*t)
        
                put_price_data_atm.append(putprice)

        return 

    put_minute_data_atm(straddle[0],put_iv)

    put_price_data_atm=pd.DataFrame(put_price_data_atm)
    time_data_put_atm=pd.DataFrame(time_data_put_atm)
    data_hourly_put_atm=pd.concat([time_data_put_atm,put_price_data_atm], axis=1)
    data_hourly_put_atm.columns=['Minutes_left','Put_price_atm']

########################################################################################################################


    """
    BlackScholes Equation for put_minute_data_otm
    
    """
     
    
    put_price_data_otm=[]
    time_data_put_otm=[]

    def put_minute_data_otm(k,iv):
        
        T=len(date_date_single_day)
        minute_left=len(date_date_single_day) + extra_time 
        
        """tick data of Call prices"""
        
        for i in range(0,T):
            
            T=T-1
            
            if(T>=0):
                
                 
                minute_left=minute_left-1
                
                t=(minute_left/1400)/365
                
                time_data_put_otm.append(minute_left)
                
                v=iv*0.0115
                
                d1= (np.log(close[i]/k) + ((0.1 +(v*v*0.5))*t)) / (v*np.sqrt(t))
                
                d2=d1-(v*np.sqrt(t))
                
                putprice= (-close[i]*norm.cdf(-d1)) + k*norm.cdf(-d2)*np.exp(-0.1*t)
        
                put_price_data_otm.append(putprice)

        return 

    put_minute_data_otm(lower_strangle,put_iv)

    put_minute_data_otm=pd.DataFrame(put_price_data_otm)
    time_data_put_otm=pd.DataFrame(time_data_put_otm)
    data_hourly_put_otm=pd.concat([time_data_put_otm,put_minute_data_otm], axis=1)
    data_hourly_put_otm.columns=['Minutes_left','Put_price_otm']
    
      
#######################################################################################################################
    
    backtest_data=pd.concat([data_hourly_call_otm,data_hourly_call_atm,data_hourly_put_atm,data_hourly_put_otm], axis=1)
    backtest_data=backtest_data[['Put_price_otm','Put_price_atm','Call_price_atm','Call_price_otm']]

    Put_price_otm=data_hourly_put_otm['Put_price_otm']
    Put_price_atm=data_hourly_put_atm['Put_price_atm']
    Call_price_atm=data_hourly_call_atm['Call_price_atm']
    Call_price_otm=data_hourly_call_otm['Call_price_otm']
    
    #stop loss logic_1

    stop_loss=Put_price_atm[21]*(1.5)

    pl=[]
    flag=1

    for i in range(21,len(Put_price_atm)-1):
        
        if Put_price_atm[i] <= stop_loss and flag==1:
            
            pl.append((Put_price_atm[21]-Put_price_atm[i+1])*75)
            
            flag=1
        
        else:
            
            pl.append((Put_price_atm[21]-stop_loss)*75)
            
            flag=0
            
            
    #stop loss logic_2

    stop_loss_put_otm=Put_price_otm[21]*(1.5)

    pl_1=[]
    flag_1=1

    for i in range(21,len(Put_price_otm)-1):
        
        if Put_price_otm[i] <= stop_loss_put_otm and flag_1==1:
            
            pl_1.append((Put_price_otm[21]-Put_price_otm[i+1])*150)
            
            flag_1=1
            
        else:
            
            pl_1.append((Put_price_otm[21]-stop_loss_put_otm)*150)
            
            flag_1=0
             
        
     #stop loss logic_3

    stop_loss_call_atm=Call_price_atm[21]*(1.5)

    pl_2=[]
    flag_2=1

    for i in range(21,len(Call_price_atm)-1):
        
        if Call_price_atm[i] <= stop_loss_call_atm and flag_2==1:
            
            pl_2.append((Call_price_atm[21]-Call_price_atm[i+1])*75)
            
            flag_2=1
        
        else:
            
            pl_2.append((Call_price_atm[21] -stop_loss_call_atm)*75)
            
            flag_2=0
            
            
            
    #stop loss logic_4

    stop_loss_call_otm=Call_price_otm[21]*(1.5)

    pl_3=[]
    flag_3=1


    for i in range(21,len(Call_price_otm)-1):
        
        if Call_price_otm[i] <= stop_loss_call_otm and flag_3 ==1:
            
            pl_3.append((Call_price_otm[21]-Call_price_otm[i+1])*150)
            
            flag_3 = 1
        
        else:
            
            pl_3.append((Call_price_otm[21]-stop_loss_call_otm)*150)
            
            flag_3 =0
            
            
    total_sum=pl + pl_1+ pl_2 + pl_3

#     plt.figure(figsize=(20,10))
#     plt.plot(total_sum, color='green')
#     plt.title("MTM minute by minute")

    profit_loss=total_sum[len(total_sum)-1]
    profit_loss=round(profit_loss,2)

    # for i in range
    
    # cummulative_return_array_old.append(profit_loss)
    

print(cummulative_return_array_old)
print(total_sum)
# cummulative_return_array_old.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short Sell\cummulative_return_array_old.csv")