import pdb
import pandas as pd
import matplotlib.pyplot as plt  
# import kite_logging
from datetime import datetime, timedelta
from kiteconnect import KiteConnect
from kite_logging import kite
import logging
from kiteconnect import KiteTicker
from pprint import pprint

logging.basicConfig(level=logging.DEBUG)

kws = KiteTicker("ojo4lqk3v7t7yac7", "KEVnR3si7MWHR7WnGjFK65DiDz5jksBJ")

intraday_data=[]

def on_ticks(ws, ticks):
    # Callback to receive ticks.
    # logging.debug("Ticks: {}".format(ticks))
    pprint(ticks)
    # ltp_data=ticks[0]['last_price']
    # pprint(ltp_data)
    intraday_data.append(ticks)
    print("\n")

def on_connect(ws, response):
    # Callback on successful connect.
    # Subscribe to a list of instrument_tokens (RELIANCE and ACC here).
    ws.subscribe([12428546])

    # Set RELIANCE to tick in `full` mode.
    ws.set_mode(ws.MODE_FULL, [12428546])

def on_close(ws, code, reason):
    # On connection close stop the event loop.
    # Reconnection will not happen after executing `ws.stop()`
    ws.stop()

# Assign the callbacks.
kws.on_ticks = on_ticks
kws.on_connect = on_connect
kws.on_close = on_close

# Infinite loop on the main thread. Nothing after this will run.
# You have to use the pre-defined callbacks to manage subscriptions.
kws.connect()

intraday_data=pd.DataFrame(intraday_data)

intraday_data.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\intraday_data.csv")
