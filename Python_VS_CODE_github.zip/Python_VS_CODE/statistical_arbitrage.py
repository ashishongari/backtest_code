import pandas as pd  
import numpy as np  
import pandas_datareader as pdr
import matplotlib.pyplot as plt  
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
import seaborn as sns  
from nsetools import Nse 
import datetime 
from datetime import datetime, timedelta
from nsepy.history import get_price_list
import pandas_datareader.data as web
from datetime import datetime, timedelta
import datetime

data = yf.download(tickers=['INFY.NS', 'TCS.NS'], start=date(2020,2,25),end=date(2021,2,25) ,interval="1m")['Close']
print(data)