import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import pandas_datareader as pdr
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import calendar
import datetime as dt
from nsetools import Nse
# import talib
import seaborn as sns
from scipy.stats import norm
# from sklearn.linear_model import LinearRegression
# from sklearn.model_selection import train_test_split 
# from sklearn.metrics import mean_squared_error, r2_score
# from sklearn import metrics
# import scipy.optimize as opt
# from sklearn.metrics import confusion_matrix 
# from sklearn.metrics import accuracy_score
# from sklearn import preprocessing
# from sklearn.neighbors import KNeighborsClassifier
import time
import threading
from time import perf_counter
import concurrent.futures
import multiprocessing
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta 
from datetime import datetime
from nsepy.history import get_price_list


# def findDay(date): 

#     born = datetime.datetime.strptime(date, '%d-%m-%Y').weekday() 

#     return (calendar.day_name[born]) 
  
# # Driver program 
# date = '21-06-1995'
# print(findDay(date))

# todayDate = datetime.date.today()
# if todayDate.day > 25:
#     todayDate += datetime.timedelta(7)

# print(todayDate.replace(day=1))

# today_date=datetime.now()
# print(today_date)


# date_str = '09-19-2018'

# date_object = datetime.strptime(date_str, '%m-%d-%Y').date()
# print(type(date_object))
# print(date_object)

# today_date_20= date_object + timedelta(days=5)
# print(today_date_20)


    # date_data=df.index.unique()
    # date_df=np.array(date_data)
    # print(date_df)

    # x=date_df[1]
    # # print(x)
    # date_dt3 = datetime.strptime(x, '%d-%m-%Y')

    # print(date_dt3.month)


import datetime

date_time_str='2020-01-01'
date_time_obj = datetime.datetime.strptime(date_time_str, '%Y-%m-%d')

print('Date:', date_time_obj.date())

# d=date_time_obj.date()


# prices = get_price_list(dt=d)
# prices =prices.loc[prices['SERIES'] == 'EQ']
# condition = prices['TOTTRDVAL'] >10_00_00_000
# prices= prices[condition]

# df=prices.loc[prices['SERIES'] == 'EQ']
# df= df[['SYMBOL']]
# stock_list=list(df.SYMBOL)
# print(len(stock_list))

