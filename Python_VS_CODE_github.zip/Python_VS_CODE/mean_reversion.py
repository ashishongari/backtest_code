import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import pandas_datareader as pdr
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
# import talib
import seaborn as sns
from statsmodels.tsa.stattools import adfuller
import statsmodels.api as sm  
from nsetools import Nse 
import datetime 
from datetime import datetime, timedelta
import time
import threading
from time import perf_counter
import concurrent.futures
import multiprocessing
from dateutil.relativedelta import relativedelta
import datetime 
from datetime import datetime


nifty_data=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Intraday 1 Min Data\nifty20152020.csv",parse_dates=True, index_col=0)
# print(nifty_data)

date_df=nifty_data['Date'].unique()
# print(date_df)

for i in range(1):

    nifty_data_run =nifty_data.copy()
    df=nifty_data_run.loc[nifty_data['Date'] == date_df[51]]
    df=df.reset_index(drop=True)
    df=df[['Time','Close']]

    df['max']=0
    df['min']=0
    df['long_signal'] =0
    df['short_signal'] =0

    df['long_exit'] =0
    df['short_exit'] =0

    df['max']=df['Close'].expanding().max()
    df['min']=df['Close'].expanding().min()

    df['Close']=df['Close'].shift(1)

    df['long_signal'] =np.where(df['Close'] > (df['Close'] + (df['min']*0.05)), 1 ,0)
    df['short_signal'] = np.where(df['Close'] < (df['Close'] - (df['max']*0.05)), 1 ,0)

    df['long_exit'] =np.where(df['Close'] < df['min'] , 1 ,0)
    df['short_exit'] = np.where(df['Close'] > df['max'], 1 ,0)

    print(df)

    plt.plot(df['Close'])
    plt.plot(df['max'])
    plt.plot(df['min'])
    plt.show()

 