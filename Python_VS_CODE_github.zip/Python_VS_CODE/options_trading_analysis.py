import numpy as np
import pandas as pd  
import numpy as np  
import math
import pandas_datareader as pdr
import yfinance as yf
import datetime 
from matplotlib.ticker import NullFormatter
import matplotlib.ticker as ticker
import matplotlib.pyplot as plt 
from datetime import date
import datetime 
import yfinance as yf
import statsmodels.api as sm
import statistics
# from sklearn import linear_model
import seaborn as sns
from scipy import stats
from scipy.stats import laplace
from scipy.stats import norm
from scipy.stats import kurtosis
import random
from scipy.stats import skew 
from numpy import log as ln
from nsetools import Nse

trade_data_wed= pd.read_csv(r'C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\trade_data_wed_modified.csv')
print(trade_data_wed.head())


# #OTM_ANALYSIS_PROFIT
# trade_data_wed_otm=trade_data_wed.copy()
# trade_data_wed_otm=trade_data_wed_otm[['Profit','OTM PE PL', 'OTM PE SELL PRICE',
#        'OTM PE BUY PRICE', 'OTM CE PL', 'OTM CE SELL PRICE',
#        'OTM CE BUY PRICE']]
# trade_data_wed_otm['result']=np.where(trade_data_wed_otm['Profit'] >0, 1, 0)
# print(trade_data_wed_otm)

# condition1=trade_data_wed_otm['result']==1
# otm_df=trade_data_wed_otm[condition1]
# print(otm_df)


# trade_data_wed_otm['otm_change']=(trade_data_wed_otm['OTM PE BUY PRICE'].div(trade_data_wed_otm['OTM PE SELL PRICE'])-1)*100

# condition=trade_data_wed_otm['otm_change'] <=50

# trade_data_wed_otm_df=trade_data_wed_otm[condition]

# condition1=trade_data_wed_otm_df['otm_change'] <0

# print(trade_data_wed_otm_df[condition1])
# print(trade_data_wed_otm_df[condition1]['otm_change'].mean())
# print(trade_data_wed_otm_df['OTM PE BUY PRICE'].mean())


# trade_data_wed_otm['otm_change']=(trade_data_wed_otm['OTM CE BUY PRICE'].div(trade_data_wed_otm['OTM CE SELL PRICE'])-1)*100
# condition=trade_data_wed_otm['otm_change'] <=50

# trade_data_wed_otm_df=trade_data_wed_otm[condition]

# condition1=trade_data_wed_otm_df['otm_change'] <0
# trade_data_wed_otm_df[condition1]
# print(trade_data_wed_otm_df[condition1]['otm_change'].mean())



