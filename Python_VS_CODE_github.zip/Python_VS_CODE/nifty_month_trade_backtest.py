import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import pandas_datareader as pdr
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
import talib
import seaborn as sns
from statsmodels.tsa.stattools import adfuller
import statsmodels.api as sm  
from nsetools import Nse 
import datetime 
from datetime import datetime, timedelta

# def four_day_nifty_logic():
#     # date_data.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\date_data_monthly.csv")
#     df=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\big_data_df_stock_nifty.csv", index_col=0)
#     # print(df)

#     date_data=df.index.unique()
#     date_data=pd.DataFrame(date_data)
#     date_data.columns=['date']

#     date_data['day_of_month']=0

#     for i in range(len(date_data)-1):
        
#         x=date_data['date'][i]
#         date_day = datetime.strptime(x, '%d-%m-%Y')

#         date_data['day_of_month'].iloc[i] = date_day.day


#     date_data['trading_day']=0
#     date_data['next_day']=0

#     for i in range(len(date_data)-1):

#         if date_data['day_of_month'].iloc[i] == 26:

#             date_data['trading_day'].iloc[i] = date_data['date'].iloc[i]
#             date_data['next_day'].iloc[i] = date_data['date'].iloc[i+3]
#         else:
#             date_data['trading_day'].iloc[i] = 0
#             date_data['next_day'].iloc[i] = 0


#     condition =date_data['trading_day'] !=0
#     date_data=date_data[condition]

#     date_data=date_data.reset_index(drop=True)

#     date_data=date_data[['trading_day','next_day']]

#     date_data['nifty_trading_day']=0
#     date_data['nifty_next_day']=0

#     #################################################################################################################################################
    
#     df_new=df=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\big_data_df_stock_nifty.csv")

#     for i in range(77,142):
        
#         live_data_trading_data=df_new.loc[df_new['date']==date_data['trading_day'][i]]
#         live_data_trading_data=live_data_trading_data.reset_index(drop=True)

#         live_data_next_data=df_new.loc[df_new['date']==date_data['next_day'][i]]
#         live_data_next_data=live_data_trading_data.reset_index(drop=True)

#         print(live_data_trading_data)
#         spot =live_data_trading_data['close'].iloc[1]
#         date_data['nifty_trading_day'].iloc[i]=spot

#         print(live_data_next_data)
#         exit=live_data_next_data['close'].iloc[-2]
#         date_data['nifty_next_day'].iloc[i]=exit



#     print(date_data)

#     # date_data.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\prior_logic_2.csv")
    
#     return 
# four_day_nifty_logic()

#####################################################################################################################################################


# def monthly_nifty_logic():
#     # date_data.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\date_data_monthly.csv")
#     df=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\big_data_df_stock_nifty.csv", index_col=0)
#     # print(df)

#     date_data=df.index.unique()
#     date_data=pd.DataFrame(date_data)
#     date_data.columns=['date']

#     date_data['day']=0
#     date_data['month']=0
#     date_data['year']=0

#     first_day_list=[]
#     last_day_list=[]

#     for i in range(len(date_data)):
        
#         x=date_data['date'][i]
#         date_day = datetime.strptime(x, '%d-%m-%Y')

#         date_data['day'].iloc[i] = date_day.day
#         date_data['month'].iloc[i] = date_day.month
#         date_data['year'].iloc[i] = date_day.year

#     year_array = date_data['year'].unique()
#     year_array=np.array(year_array)

#     month_array = [1,2,3,4,5,6,7,8,9,10,11,12]
#     month_array=np.array(month_array)
    
#     condition_1 =date_data['year'] ==year_array[2]
#     date_data=date_data[condition_1]
    
#     condition_2 =date_data['month'] ==month_array[0]
#     date_data=date_data[condition_2]

#     first_day=date_data['date'].iloc[0]
#     last_day=date_data['date'].iloc[-1]

#     print(first_day)
#     print(last_day)

    # date_data['trading_day']=0
    # # date_data['next_day']=0

    # for i in range(len(date_data)-1):

    #     if date_data['day_of_month'].iloc[i] == 30:

    #         date_data['trading_day'].iloc[i] = date_data['date'].iloc[i]
    #         date_data['next_day'].iloc[i] = date_data['date'].iloc[i+1]
    #     else:
    #         date_data['trading_day'].iloc[i] = 0
    #         date_data['next_day'].iloc[i] = 0


    # condition =date_data['trading_day'] !=0
    # date_data=date_data[condition]

    # date_data=date_data.reset_index(drop=True)

    # date_data=date_data[['trading_day','next_day']]

    # date_data['nifty_trading_day']=0
    # date_data['nifty_next_day']=0

    # #################################################################################################################################################
    
    # df_new=df=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\big_data_df_stock_nifty.csv")

    # for i in range(77,142):
        
    #     live_data_trading_data=df_new.loc[df_new['date']==date_data['trading_day'][i]]
    #     live_data_trading_data=live_data_trading_data.reset_index(drop=True)

    #     live_data_next_data=df_new.loc[df_new['date']==date_data['next_day'][i]]
    #     live_data_next_data=live_data_trading_data.reset_index(drop=True)

    #     print(live_data_trading_data)
    #     spot =live_data_trading_data['close'].iloc[1]
    #     date_data['nifty_trading_day'].iloc[i]=spot

    #     print(live_data_next_data)
    #     exit=live_data_next_data['close'].iloc[-2]
    #     date_data['nifty_next_day'].iloc[i]=exit


    # date_data.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\prior_logic_2.csv")
    
#     return print(date_data)

# monthly_nifty_logic()



 # date_data.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\date_data_monthly.csv")

df=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\big_data_df_stock_nifty.csv", index_col=0)
# print(df)

date_data=df.index.unique()
date_data=pd.DataFrame(date_data)
date_data.columns=['date']

date_data['day']=0
date_data['month']=0
date_data['year']=0

first_day_list=[]
last_day_list=[]

for i in range(len(date_data)):
    
    x=date_data['date'][i]
    date_day = datetime.strptime(x, '%d-%m-%Y')

    date_data['day'].iloc[i] = date_day.day
    date_data['month'].iloc[i] = date_day.month
    date_data['year'].iloc[i] = date_day.year

year_array = date_data['year'].unique()
year_array=np.array(year_array)

month_array = date_data['month'].unique()
month_array=np.array(month_array)
# print(date_data)

day=[]

for i in range(len(year_array)-1):

    date_data=date_data.copy()
    condition_1 =date_data['year'] ==year_array[i]
    new_data=date_data[condition_1]
    new_data=new_data.dropna()
    new_data=new_data.reset_index(drop=True)
  
    condition_2 =new_data['month'] ==9
    new_data_df=new_data[condition_2]
    new_data_df=new_data_df.dropna()
    new_data_df=new_data_df.reset_index(drop=True)

    first_day=new_data_df['date'].iloc[0]
    last_day=new_data_df['date'].iloc[-1]

    # print(first_day)
    # print(last_day)

    day.append(first_day)


day=pd.DataFrame(day)
day.columns=['date']
print(day)





