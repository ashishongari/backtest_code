import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import pandas_datareader as pdr
import yfinance as yf
from nsepy import get_history
from datetime import date
from nsetools import Nse
from statsmodels.tsa.stattools import adfuller
import statsmodels.api as sm  
from nsetools import Nse 
from datetime import datetime, timedelta
from nsetools import Nse 
from nsepy.history import get_price_list
import pandas_datareader.data as web



def historical_price():
    
    prices = get_price_list(dt=date(2021,2,18))
    prices =prices.loc[prices['SERIES'] == 'EQ']
    condition = prices['TOTTRDVAL'] >25_00_00_000
    prices= prices[condition]

    df=prices.loc[prices['SERIES'] == 'EQ']
    df= df[['SYMBOL']]
    stock_list=list(df.SYMBOL)

    ticker_list=[]

    for i in range(len(stock_list)):
        end='.NS'
        symbol=stock_list[i] + end
        ticker_list.append(symbol)

    print(ticker_list)

    print(f"number of stocks is {len(ticker_list)}")

    start = datetime.datetime(2007, 1, 1)
    end = datetime.datetime(2021, 2, 24)

    close_price = web.DataReader(ticker_list, 'yahoo', start, end)['Adj Close']
    print(close_price)

    close_price.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\equity_data.csv")

# historical_price()

#################################################################################################################################

def bhavcopy_dataframe():
    
    sbin = get_history(symbol='SBIN', start=date(2021,1,1),end=date(2021,1,5))[['Close', 'Open']]
    sbin['date'] =sbin.index
    sbin['date']=pd.to_datetime(sbin['date'])
    sbin['day'] =sbin['date'].dt.day
    day_list = list(sbin['day'])

    print(day_list)

    for i in day_list:
        
        prices = get_price_list(dt=date(2021,1,i))
        print(prices)
 
# bhavcopy_dataframe()

############################################################################################################################

def random_stock_data():
    
    df=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\index_stock_list.csv", index_col=0)
    stock_list=list(df.index)

    # stock_list = ['ALKYLAMINE', 'APLAPOLLO', 'ATUL', 'BALKRISIND', 'BHARTIARTL', 'GARFIBRES','HEROMOTOCO', 'BSE', 'POLYCAB', 'LALPATHLAB', 'MANAPPURAM', 'MCDOWELL-N', 'NAUKRI', 'SBIN', 'TCS']
    # stock_list=['DBCROP', 'RUCHI']

    ticker_list=[]

    for i in range(len(stock_list)):
        end='.NS'
        symbol=stock_list[i] + end
        ticker_list.append(symbol)

    # ticker_list=ticker_list[201:300]

    
    print(ticker_list)
    print(len(ticker_list))

    start = datetime(2010, 1, 1)
    end = datetime(2021, 3, 1)

    close_price = web.DataReader(ticker_list, 'yahoo', start, end)['Adj Close']
    print(close_price)

    # close_price.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\index_data_3.csv")

random_stock_data()

################################################################################################################################

def derivative_stock_price():
    
    nse = Nse()
    x= nse.get_fno_lot_sizes()
    list_stock = x.keys()
    list_stock=list(list_stock)
    list_stock=list_stock[3:]
    banned_list = ['MANPASAND', 'JETAIRWAYS','DHFL', 'PCJEWELLER', 'ZEEL','IBULHSGFIN','']
    full_list = list_stock + banned_list

    print(full_list)

    ticker_list=[]

    for i in range(len(list_stock)):
        end='.NS'
        symbol=list_stock[i] + end
        ticker_list.append(symbol)

    print(ticker_list)

    start = datetime.datetime(2021, 1, 1)
    end = datetime.datetime(2021, 1, 3)

    # close_price = web.DataReader(ticker_list, 'yahoo', start, end)['Close']
    # print(close_price)


# derivative_stock_price()





