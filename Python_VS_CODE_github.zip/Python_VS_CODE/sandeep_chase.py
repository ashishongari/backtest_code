import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import pandas_datareader as pdr
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
import seaborn as sns
from statsmodels.tsa.stattools import adfuller
import statsmodels.api as sm  
from nsetools import Nse 
from nsepy.history import get_price_list
import glob

def chase_logic():
    
    fut=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\sandeep_fut_bnf.csv",parse_dates=True, index_col=0)

    fut['Exit Date']=pd.to_datetime(fut['Exit Date'])
    fut['Entry Date']=fut.index
    fut['Entry Date']=pd.to_datetime(fut['Entry Date'])

    fut=fut[['Entry Date', 'Entry', 'Exit Date', 'Exit']]
    fut=fut.reset_index(drop=True)
    # print(fut.head(50))
    nifty=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\niftybank.csv",parse_dates=True, index_col=0)

    nifty['Date']=nifty.index
    nifty.columns=['nifty' , 'Date']
    nifty=nifty[['Date', 'nifty']]
    nifty=nifty.reset_index(drop=True)
    # print(nifty.head(50))
    
    position=[]
    date=[]
    trade_position=[]

    for i in range(len(fut)):

        position.append(fut['Entry'].iloc[i])
        position.append(fut['Exit'].iloc[i])

        date.append(fut['Entry Date'].iloc[i])
        date.append(fut['Exit Date'].iloc[i])

        trade_position.append('Entry')
        trade_position.append('Exit')

    position=pd.DataFrame(position)
    date=pd.DataFrame(date)
    trade_position=pd.DataFrame(trade_position)

    final_df=pd.concat([date, trade_position, position], axis=1)
    final_df.columns=['Date', 'trade_position','Postion']

############################################################################################

    chase_df = pd.merge(nifty,   final_df,  on ='Date',  how ='left')

    chase_df['trade_position']=chase_df['trade_position'].replace(np.nan, 'Live')
    chase_df['Postion']=chase_df['Postion'].replace(np.nan, 0)

    chase_df['nifty_position']=0

    for i in range(len(chase_df)):

        if chase_df['Postion'].iloc[i] == 0:

            chase_df['nifty_position'].iloc[i] = chase_df['nifty'].iloc[i]
        
        else:

            chase_df['nifty_position'].iloc[i] = chase_df['Postion'].iloc[i]
    
##################################################################################################

    chase_df['position'] =0

    for i in range(len(chase_df)):

        if chase_df['trade_position'].iloc[i] =='Entry' and chase_df['nifty_position'].iloc[i] < 0:

            chase_df['position'].iloc[i] ='Short'

        elif chase_df['trade_position'].iloc[i] =='Entry' and chase_df['nifty_position'].iloc[i] > 0:

            chase_df['position'].iloc[i] ='Long'

        elif chase_df['trade_position'].iloc[i] =='Exit':

            chase_df['position'].iloc[i] ='Exit'  

        else:
            chase_df['position'].iloc[i]='Live'

    chase_df = chase_df[['Date' , 'nifty','nifty_position', 'position']]

    chase_df['nifty_position'] = abs(chase_df['nifty_position'])
    
##################################################################################################
    """
    LONG POSITION
    """
    chase_df['z_signal_buy_entry']= 0
    chase_df['buy_exit']= 0
    chase_df['buy_position']=0

    for i in range(len(chase_df)):

        if chase_df['position'].iloc[i] =='Long':

            chase_df['z_signal_buy_entry'].iloc[i]= 1

        else:

            chase_df['z_signal_buy_entry'].iloc[i]= 0

    for i in range(len(chase_df)):

        if chase_df['position'].iloc[i] =='Short' or chase_df['position'].iloc[i] =='Exit' :

            chase_df['buy_exit'].iloc[i]= 1

        else:

            chase_df['buy_exit'].iloc[i]= 0

    for i in range(len(chase_df)):
        
        if (chase_df['z_signal_buy_entry'].iloc[i] ==0 and chase_df['buy_exit'].iloc[i] ==1) and (chase_df['buy_position'].iloc[i-1] =='postion_live'):
            
            chase_df['buy_position'].iloc[i]='no_position'
            
        elif (chase_df['z_signal_buy_entry'].iloc[i] ==1 and chase_df['buy_exit'].iloc[i] ==0) or (chase_df['buy_position'].iloc[i-1] =='postion_live') :
            
            chase_df['buy_position'].iloc[i]='postion_live'
                
        else :
            
            chase_df['buy_position'].iloc[i]='no_position'
    
##################################################################################################
    """
    SHORT POSITION
    """
    chase_df['z_signal_sell_entry']= 0
    chase_df['sell_exit']= 0
    chase_df['sell_position']=0

    for i in range(len(chase_df)):

        if chase_df['position'].iloc[i] =='Short':

            chase_df['z_signal_sell_entry'].iloc[i]= 1

        else:

            chase_df['z_signal_sell_entry'].iloc[i]= 0

    for i in range(len(chase_df)):

        if chase_df['position'].iloc[i] =='Long' or chase_df['position'].iloc[i] =='Exit':

            chase_df['sell_exit'].iloc[i]= 1

        else:

            chase_df['sell_exit'].iloc[i]= 0

    for i in range(len(chase_df)):
        
        if (chase_df['z_signal_sell_entry'].iloc[i] ==0 and chase_df['sell_exit'].iloc[i] ==1) and (chase_df['sell_position'].iloc[i-1] =='postion_live'):
            
            chase_df['sell_position'].iloc[i]='no_position'
            
        elif (chase_df['z_signal_sell_entry'].iloc[i] ==1 and chase_df['sell_exit'].iloc[i] ==0) or (chase_df['sell_position'].iloc[i-1] =='postion_live') :
            
            chase_df['sell_position'].iloc[i]='postion_live'
                
        else :
            
            chase_df['sell_position'].iloc[i]='no_position'

    chase_df=chase_df[['Date','nifty' ,'position','nifty_position', 'buy_position', 'sell_position']]

##########################################################################################################

    chase_df['long_mtm'] = 0
    chase_df['short_mtm'] = 0

    for i in range(len(chase_df)):

        # if chase_df['position'].iloc[i] =='Long' and chase_df['Date'].iloc[i] != chase_df['Date'].iloc[i-1] and chase_df['position'].iloc[i-1] !='Long':

        #     chase_df['long_mtm'].iloc[i] =  chase_df['nifty'].iloc[i] - chase_df['nifty_position'].iloc[i]

        if  chase_df['position'].iloc[i] =='Long' and chase_df['Date'].iloc[i] ==chase_df['Date'].iloc[i-1]  and chase_df['position'].iloc[i-1] !='Long':
            
            chase_df['long_mtm'].iloc[i] =  chase_df['nifty'].iloc[i] - chase_df['nifty_position'].iloc[i]

        elif chase_df['buy_position'].iloc[i] =='postion_live' and  chase_df['position'].iloc[i] =='Long' and chase_df['position'].iloc[i-1] !='Long' :
            
            chase_df['long_mtm'].iloc[i] =0
        
        elif chase_df['buy_position'].iloc[i] =='postion_live' and  chase_df['position'].iloc[i] =='Live': 
            
            chase_df['long_mtm'].iloc[i] = chase_df['nifty_position'].iloc[i] - chase_df['nifty'].iloc[i-1]
        
        elif chase_df['buy_position'].iloc[i-1] =='postion_live' and chase_df['position'].iloc[i] =='Exit' and chase_df['Date'].iloc[i] ==chase_df['Date'].iloc[i-1]: 

            chase_df['long_mtm'].iloc[i] =  chase_df['nifty_position'].iloc[i] - chase_df['nifty_position'].iloc[i-1]

        elif chase_df['buy_position'].iloc[i-1] =='postion_live' and chase_df['position'].iloc[i] =='Exit' and chase_df['Date'].iloc[i] !=chase_df['Date'].iloc[i-1]: 

            chase_df['long_mtm'].iloc[i] =   chase_df['nifty_position'].iloc[i] - chase_df['nifty'].iloc[i-1]
    
        else:

            chase_df['long_mtm'].iloc[i] =0

#########################################################################################

    for i in range(len(chase_df)):

        # if chase_df['position'].iloc[i] =='Short' and chase_df['Date'].iloc[i] != chase_df['Date'].iloc[i-1] and chase_df['position'].iloc[i-1] !='Short':

        #      chase_df['short_mtm'].iloc[i] = chase_df['nifty_position'].iloc[i] - chase_df['nifty'].iloc[i]

        if  chase_df['position'].iloc[i] =='Short' and chase_df['Date'].iloc[i] ==chase_df['Date'].iloc[i-1] and chase_df['position'].iloc[i-1] !='Short':
            
            chase_df['short_mtm'].iloc[i] = chase_df['nifty_position'].iloc[i] - chase_df['nifty'].iloc[i]

        elif chase_df['sell_position'].iloc[i] =='postion_live' and  chase_df['position'].iloc[i] =='Short' and chase_df['position'].iloc[i-1] !='Short' :
            
            chase_df['short_mtm'].iloc[i] =0
        
        elif chase_df['sell_position'].iloc[i] =='postion_live' and  chase_df['position'].iloc[i] =='Live': 
            
            chase_df['short_mtm'].iloc[i] = chase_df['nifty'].iloc[i-1] - chase_df['nifty_position'].iloc[i]
        
        elif chase_df['sell_position'].iloc[i-1] =='postion_live' and chase_df['position'].iloc[i] =='Exit' and chase_df['Date'].iloc[i] ==chase_df['Date'].iloc[i-1]: 

            chase_df['short_mtm'].iloc[i] = chase_df['nifty_position'].iloc[i-1] - chase_df['nifty_position'].iloc[i]

        elif chase_df['sell_position'].iloc[i-1] =='postion_live' and chase_df['position'].iloc[i] =='Exit' and chase_df['Date'].iloc[i] !=chase_df['Date'].iloc[i-1]: 

            chase_df['short_mtm'].iloc[i] = chase_df['nifty'].iloc[i-1] - chase_df['nifty_position'].iloc[i]
    
        else:

            chase_df['short_mtm'].iloc[i] =0

#################################################################################################

    chase_df['MTM'] = chase_df['long_mtm'] +  chase_df['short_mtm']

    chase_df=chase_df[['Date','nifty', 'position' ,'nifty_position', 'MTM']]

    print(chase_df.head(50)) 
    
    # print(chase_df['MTM'].sum(axis=0))

    chase_df.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\bnf_chase.csv")
  
chase_logic()







