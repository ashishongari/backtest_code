
def main():
    print('First module name: {}'.format(__name__))

if __name__ =='__main__':
    main()
