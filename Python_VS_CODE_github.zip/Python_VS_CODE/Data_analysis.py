import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import pandas_datareader as pdr
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
# import talib
import seaborn as sns
from statsmodels.tsa.stattools import adfuller
import statsmodels.api as sm  
from nsetools import Nse 
from nsepy.history import get_price_list
import glob
from nsepy import get_history
from datetime import date


# def chase_trade():
    
#     # etf=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\sandeep_etf.csv",parse_dates=True, index_col=0)
#     fut=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\sandeep_fut.csv",parse_dates=True, index_col=0)
#     fut['Exit Date']=pd.to_datetime(fut['Exit Date'])
#     fut['Entry Date']=fut.index
#     fut['Entry Date']=pd.to_datetime(fut['Entry Date'])

#     fut=fut[['Entry Date', 'Entry', 'Exit Date', 'Exit']]
#     fut=fut.reset_index(drop=True)

#     # print(fut)

#     nifty=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\nifty.csv",parse_dates=True, index_col=0)

#     nifty['Date']=nifty.index
#     nifty.columns=['nifty' , 'Date']
#     nifty=nifty[['Date', 'nifty']]
#     nifty=nifty.reset_index(drop=True)
#     # print(nifty)

#     position=[]
#     date=[]
#     trade_position=[]

#     for i in range(len(fut)):

#         position.append(fut['Entry'].iloc[i])
#         position.append(fut['Exit'].iloc[i])

#         date.append(fut['Entry Date'].iloc[i])
#         date.append(fut['Exit Date'].iloc[i])

#         trade_position.append('Entry')
#         trade_position.append('Exit')

#     # print(position)
#     # print(date)

#     position=pd.DataFrame(position)
#     date=pd.DataFrame(date)
#     trade_position=pd.DataFrame(trade_position)

#     final_df=pd.concat([date, trade_position, position], axis=1)
#     final_df.columns=['Date', 'trade_position','Postion']

#     # print(final_df.head(20))

#     chase_df = pd.merge(nifty,   final_df,  on ='Date',  how ='left')

#     chase_df['trade_position']=chase_df['trade_position'].replace(np.nan, 'Live')
#     chase_df['Postion']=chase_df['Postion'].replace(np.nan, 0)

#     chase_df['nifty_position']=0

#     for i in range(len(chase_df)):

#         if chase_df['Postion'].iloc[i] == 0:

#             chase_df['nifty_position'].iloc[i] = chase_df['nifty'].iloc[i]
        
#         else:

#             chase_df['nifty_position'].iloc[i] = chase_df['Postion'].iloc[i]


#     chase_df['position'] =0

#     for i in range(len(chase_df)):

#         if chase_df['trade_position'].iloc[i] =='Entry' and chase_df['nifty_position'].iloc[i] < 0:

#             chase_df['position'].iloc[i] ='Short'

#         elif chase_df['trade_position'].iloc[i] =='Entry' and chase_df['nifty_position'].iloc[i] > 0:

#             chase_df['position'].iloc[i] ='Long'

#         else:
#             chase_df['position'].iloc[i]='Live'


#     chase_df = chase_df[['Date' , 'nifty_position', 'position']]

#     chase_df['nifty_position'] = abs(chase_df['nifty_position'])    

#     ################################################################################################

#     """
#     LONG POSITION
#     """

#     chase_df['z_signal_buy_entry']= 0
#     chase_df['buy_exit']= 0
#     chase_df['buy_position']=0

#     for i in range(len(chase_df)):

#         if chase_df['position'].iloc[i] =='Long':

#             chase_df['z_signal_buy_entry'].iloc[i]= 1

#         else:

#             chase_df['z_signal_buy_entry'].iloc[i]= 0


#     for i in range(len(chase_df)):

#         if chase_df['position'].iloc[i] =='Short':

#             chase_df['buy_exit'].iloc[i]= 1

#         else:

#             chase_df['buy_exit'].iloc[i]= 0


#     for i in range(len(chase_df)):
        
#         if (chase_df['z_signal_buy_entry'].iloc[i] ==0 and chase_df['buy_exit'].iloc[i] ==1) and (chase_df['buy_position'].iloc[i-1] =='postion_live'):
            
#             chase_df['buy_position'].iloc[i]='no_position'
            
#         elif (chase_df['z_signal_buy_entry'].iloc[i] ==1 and chase_df['buy_exit'].iloc[i] ==0) or (chase_df['buy_position'].iloc[i-1] =='postion_live') :
            
#             chase_df['buy_position'].iloc[i]='postion_live'
                
#         else :
            
#             chase_df['buy_position'].iloc[i]='no_position'



#     ################################################################################################

#     """
#     SHORT POSITION
#     """

#     chase_df['z_signal_sell_entry']= 0
#     chase_df['sell_exit']= 0
#     chase_df['sell_position']=0

#     for i in range(len(chase_df)):

#         if chase_df['position'].iloc[i] =='Short':

#             chase_df['z_signal_sell_entry'].iloc[i]= 1

#         else:

#             chase_df['z_signal_sell_entry'].iloc[i]= 0


#     for i in range(len(chase_df)):

#         if chase_df['position'].iloc[i] =='Long':

#             chase_df['sell_exit'].iloc[i]= 1

#         else:

#             chase_df['sell_exit'].iloc[i]= 0


#     for i in range(len(chase_df)):
        
#         if (chase_df['z_signal_sell_entry'].iloc[i] ==0 and chase_df['sell_exit'].iloc[i] ==1) and (chase_df['sell_position'].iloc[i-1] =='postion_live'):
            
#             chase_df['sell_position'].iloc[i]='no_position'
            
#         elif (chase_df['z_signal_sell_entry'].iloc[i] ==1 and chase_df['sell_exit'].iloc[i] ==0) or (chase_df['sell_position'].iloc[i-1] =='postion_live') :
            
#             chase_df['sell_position'].iloc[i]='postion_live'
                
#         else :
            
#             chase_df['sell_position'].iloc[i]='no_position'

#     chase_df=chase_df[['Date', 'nifty_position', 'buy_position', 'sell_position']]


#     ######################################################################################

#     chase_df['long_mtm'] = 0
#     chase_df['short_mtm'] = 0

#     for i in range(len(chase_df)):

#         if chase_df['buy_position'].iloc[i] =='postion_live' and  chase_df['buy_position'].iloc[i-1] !='no_position':

#             chase_df['long_mtm'].iloc[i] = chase_df['nifty_position'].iloc[i] - chase_df['nifty_position'].iloc[i-1]

#         else:

#             chase_df['long_mtm'].iloc[i] =0

#     #########################################################################################

#     for i in range(len(chase_df)):

#         if chase_df['sell_position'].iloc[i] =='postion_live' and  chase_df['sell_position'].iloc[i-1] !='no_position':

#             chase_df['short_mtm'].iloc[i] = (chase_df['nifty_position'].iloc[i] - chase_df['nifty_position'].iloc[i-1])*-1

#         else:

#             chase_df['short_mtm'].iloc[i] =0

#     ###########################################################################

#     """
#     MTM CALCULATIONS
#     """

#     chase_df['MTM'] = chase_df['long_mtm'] +  chase_df['short_mtm']

#     chase_df=chase_df[['Date' , 'MTM']]

#     f = {'Date' : 'nunique',  }

#     g = chase_df.groupby(['Date', 'Date'])
#     v1 = g.agg(f)
#     v2 = g.agg(lambda x: x.drop_duplicates('Date', keep='first').MTM.sum())

#     df = pd.concat([v1, v2.to_frame('MTM')], 1)
#     # df=df.reset_index(drop=True)

#     df=df.drop(['Date'], axis=1)

#     print(df)

# chase_trade()

# nifty=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\NIFTY_Bank_Data.csv", parse_dates=True, index_col=0)
# nifty['ma']=nifty['Close'].rolling(window=200).mean()
# nifty=nifty.dropna()

# nifty['diff'] = nifty['Close'] -nifty['ma']  
# nifty['expansion_contraction']= (nifty['diff']/ nifty['Close'])*100
# nifty['axe']=0
# nifty['25_upper']=25
# print(nifty)

# plt.plot(nifty['axe'])
# plt.plot(nifty['expansion_contraction'])
# plt.plot(nifty['25_upper'])
# plt.title("BANK_NIFTY_expansion_contraction")
# plt.show()

# nifty['z_signal_buy_entry']=np.where( nifty['expansion_contraction'] >=25,1,0)

# nifty['buy_exit']=np.where( nifty['expansion_contraction'] <15 ,1,0)

# nifty['buy_position']=0

# for i in range(len(nifty)):
    
#     if (nifty['z_signal_buy_entry'].iloc[i] ==0 and nifty['buy_exit'].iloc[i] ==1) and (nifty['buy_position'].iloc[i-1] =='postion_live'):
        
#         nifty['buy_position'].iloc[i]='no_position'
        
#     elif (nifty['z_signal_buy_entry'].iloc[i] ==1 and nifty['buy_exit'].iloc[i] ==0) or (nifty['buy_position'].iloc[i-1] =='postion_live') :
        
#          nifty['buy_position'].iloc[i]='postion_live'
            
#     else :
        
#         nifty['buy_position'].iloc[i]='no_position'


# nifty['mtm'] = 0

# for i in range(len(nifty)):

#     if  nifty['buy_position'].iloc[i]=='postion_live':

#         nifty['mtm'].iloc[i] = (nifty['Close'].iloc[i]- nifty['Close'].iloc[i-1])*(-1)

#     else:

#          nifty['mtm'].iloc[i] = 0


# print( nifty['mtm'].sum(axis=0))

# https://tvc4.forexpros.com/41b43920de89d45218703734672d2a06/1608641691/1/1/8/history?symbol=101810&resolution=D&from=1577537697&to=1608641757

# df_1=get_history('NIFTY PHARMA', start=date(2020,1,1), end=date.today(), index=True)['Close']
# df_2=get_history('NIFTY 50', start=date(2020,1,1), end=date.today(), index=True)['Close']

# df= df_1/df_2
# plt.plot(df)
# # plt.plot(nifty_bank , label='nifty bank')
# # plt.legend()
# plt.show()

# def stock_data():
    
#     df=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\stock_jan_2005_dec_2020_F&O.csv", parse_dates=True, index_col=0)
#     df=df.replace(np.nan, 0)
#     df['Date'] =df.index
#     df=df.reset_index(drop=True)
#     df['Date'] =pd.to_datetime(df['Date'])

#     new_df=df.copy()
#     mask = (new_df['Date'] >= '2020-01-01') & (new_df['Date'] <= '2020-12-24')
#     new_df = new_df.loc[mask]
#     new_df=new_df.reset_index(drop=True)
#     new_df=new_df.drop(columns=['Date'])
#     # print(new_df)

#     net_return =(new_df.iloc[-1]/new_df.iloc[0]) -1
#     # net_return=net_return*100

#     net_return=pd.DataFrame(net_return)
#     net_return.columns=['percent_return']
#     net_return=net_return.replace([np.inf, -np.inf], 0)
#     condition = net_return['percent_return'] != 0
#     net_return=net_return[condition]
#     net_return=net_return.sort_values(by=['percent_return'], ascending=False) 
#     net_return['stock'] =net_return.index
#     net_return=net_return.reset_index(drop=True)
#     net_return[['Stock','Last']] = net_return.stock.str.split('.', expand=True) 
#     net_return=net_return[['Stock', 'percent_return']]

#     # net_return.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\derivatives_gainers_loser_jan_dec_2020.csv")

#     print(net_return)

# stock_data()

# df=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\bnf_chase.csv", parse_dates=True, index_col=0)

# df['MTM'] =df['MTM']*(35)

# df['Portfolio'] = 0

# for i in range(len(df)):

#     if i ==0:

#         df['Portfolio'].iloc[i] =5_00_000

#     else:

#         df['Portfolio'].iloc[i] = df['Portfolio'].iloc[i-1] + df['MTM'].iloc[i]

# df['daily_return'] = 0

# for i in range(len(df)):

#     if i == 0:

#         df['daily_return'].iloc[i] = 0

#     else:

#         df['daily_return'].iloc[i] = (df['Portfolio'].iloc[i]/ df['Portfolio'].iloc[i-1])-1

# rolling_return = df['daily_return'].rolling(window=252).sum()
# rolling_std = df['daily_return'].rolling(window=252).std()*np.sqrt(252)
# rolling_sharpe=  rolling_return/ rolling_std

# avg_sharpe =rolling_sharpe.mean()

# print(avg_sharpe)
# plt.plot(rolling_sharpe)
# plt.title("Rolling_Sharpe_Ratio")
# plt.show()

# window = 50
# Roll_Max_portfolio = df['Portfolio'].rolling(window, min_periods=1).max()
# Daily_Drawdown_portfolio = (df['Portfolio']/Roll_Max_portfolio - 1)*100

# plt.plot(Daily_Drawdown_portfolio)
# plt.title("BNF Drawdown")
# plt.show()

# plt.plot(df['Portfolio'])
# plt.title("BNF Equity_Curve")
# plt.show()

# rolling_return =df['Portfolio'].rolling(window=252).sum()

# print(net_return)

# df.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\df_emw_200.csv")


# df=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\sandeep_fut.csv", parse_dates=True, index_col=0)
# # df=df.drop(columns=['Unnamed: 4'])

# df['Entry_date'] =df.index
# df=df.reset_index(drop=True)

# # df =df[["Entry_price", 'Date', 'Ex. date', 'Exit Price']]
# # df.columns= ["Entry_price", 'Entry_date', 'Exit_date', 'Exit_Price']

# df['Entry_date'] =pd.to_datetime(df['Entry_date'])
# df['Exit Date'] =pd.to_datetime(df['Exit Date'])

# df['Days'] = df['Exit Date'] - df['Entry_date']

# df['Position'] =np.where( df['Entry']  > 0 , 1, -1)
# df.columns = ['Entry_Price', 'Exit_Price', 'Exit_Date', 'Entry_Date', 'Days', 'Position']
# # df=df.replace(np.nan, 0)

# df['Entry_Price'] = abs(df['Entry_Price'])

# df['profit_loss'] = 0

# for i in range(len(df)):

#     if df['Position'].iloc[i] == 1:

#         df['profit_loss'].iloc[i] = df['Exit_Price'].iloc[i] -df ['Entry_Price'].iloc[i]

#     elif df['Position'].iloc[i] == -1:

#         df['profit_loss'].iloc[i] =  df ['Entry_Price'].iloc[i] - df['Exit_Price'].iloc[i] 

#     else:

#         df['profit_loss'].iloc[i] = 0


# condition = df['profit_loss'] > 0
# df=df[condition]

# # day = datetime.timedelta(days=4)

# # condition_1 = df['Days'] < day
# # df=df[condition_1]

# print(df['profit_loss'].median())
# print(df)


# df.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\USD_INR_FILE\chase_trade_stats.csv")



# data = pdr.get_data_yahoo('GME', start="2005-01-01", end="2020-12-31")

# data['pct_change']=data['Adj Close'].pct_change().mul(100)

# daily_vol = data['pct_change'].std()*np.sqrt(252)

# sigma= 1700/daily_vol

# print(f"Annul Vol (1SD) is around : {daily_vol} percent")

# print(f"YTD rise of stock is 1700%, So it is : {sigma} sigma event")



# def moving_average(avg_num):
    
#     df =pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\long_term_price.csv")
#     df=df.replace(np.nan, 0)

#     df=df.ewm(span=avg_num, adjust=False).mean()

#     df.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\long_term_price_200ema.csv")

#     print(df)

# moving_average(200)

# data = yf.download(
# 		tickers=['^IXIC'], 
# 		# use "period" instead of start/end
# 		# valid periods: 1d,5d,1mo,3mo,6mo,1y,2y,5y,10y,ytd,max
# 		# (optional, default is '1mo')
# 		period="max",
# 		# fetch data by interval (including intraday if period < 60 days)
# 		# valid intervals: 1m,2m,5m,15m,30m,60m,90m,1h,1d,5d,1wk,1mo,3mo
#        	# (optional, default is '1d')
# 		interval="dm")
# # Plot the close prices
# print(data)
# data.Close.plot()
# plt.show()


# data = pdr.get_data_yahoo('INR=X', start="2000-01-01", end="2021-02-12")
# print(data)

# data.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\usd_inr_eod.csv")



# df=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\NIFTY_50.csv")
# df =df.replace(np.nan, 0)
# close =df['Close']

# rolling_m_avg= close.rolling(window= 30).mean()
# rolling_std= close.rolling(window=30).std()

# plt.plot(rolling_std)
# plt.show()

# print(close)

# data.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\N100_df.csv")

# student ={'1':'First','2':'Second', '3':'Third'}

# # student.update({'1':'Last'})
# print(student)

# for i in student:
#     # print(student[i])
#     print(student.get(i))


# def finnifty_data():
    
#     from scipy.stats import pearsonr
#     data = yf.download(tickers=['^NSEBANK'], period="max",interval="1d")
#     data['pct_change'] =data['Close'].pct_change()
#     data['finnifty'] = 0
#     data=data.sort_index(ascending=False)
#     data['finnifty'].iloc[0] =17600

#     for i in range(len(data)):

#         if i ==0:

#             data['finnifty'].iloc[i]= 17_600

#         else:
            
#             data['finnifty'].iloc[i]=data['finnifty'].iloc[i-1]*( 1 - data['pct_change'].iloc[i])

#     # data=data.replace(np.nan, 0)

#     data=data.sort_index(ascending=True)

#     print(data)
#     plt.plot(data['finnifty'])
#     plt.yscale("log")
#     plt.show()

#     data=data.dropna()

#     corr, _ = pearsonr(data['Close'], data['finnifty'])

#     print('Pearsons correlation: %.3f' % corr)



# # from nsepy.history import get_price_list
# # prices = get_price_list(dt=date(2015,1,1))
# # print(prices)


# sbin = get_history(symbol='SBIN', start=date(2015,1,1),end=date(2015,1,10))[['Close', 'Open']]


# sbin['date'] =sbin.index
# sbin['date']=pd.to_datetime(sbin['date'])
# sbin['day'] =sbin['date'].dt.day

# day_list = list(sbin['day'])

# print(day_list)

# # df['month'] = df['Date'].dt.month

# for i in day_list:

#     prices = get_price_list(dt=date(2015,1,i))

#     # print((i,1,2020))
#     print(prices)




# data = yf.download(tickers=['^NSEBANK','^NSEI' ,'^KS11', '^HSI', '^N225', '^JKSE', 'PSEI.PS' , '^TWII'], period="2mo",interval="1d")['Close']
# data=data.replace(np.nan, 0)
# print(data)

def adani_index():
    
    data=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\adani.csv")
    data['outstanding_shares'] =(data['Free float percent'] * data['Total Shares']).div(100)
    # print(data)

    adani_ent = get_history(symbol="ADANIENT", start=date(2018,1,1), end=date(2021,2,18))['Close']
    atgl = get_history(symbol="ATGL", start=date(2018,1,1), end=date(2021,2,18))['Close']
    adani_green = get_history(symbol="ADANIGREEN", start=date(2018,1,1), end=date(2021,2,18))['Close']
    adani_port = get_history(symbol="ADANIPORTS", start=date(2018,1,1), end=date(2021,2,18))['Close']
    adani_power = get_history(symbol="ADANIPOWER", start=date(2018,1,1), end=date(2021,2,18))['Close']
    adani_trans = get_history(symbol="ADANITRANS", start=date(2018,1,1), end=date(2021,2,18))['Close']
    reliance = get_history(symbol="RELIANCE", start=date(2018,1,1), end=date(2021,2,18))['Close']

    df =pd.concat([adani_ent, atgl, adani_green, adani_port, adani_power, adani_trans, reliance], axis=1)
    df.columns=['ADANIENT', 'ATGL', 'ADANIGREEN', 'ADANIPORTS', 'ADANIPOWER', 'ADANITRANS', 'RELIANCE']
    df=df.replace(np.nan, 0)
    # print(df)

    df['ADANIENT'] =data.iloc[0]['outstanding_shares'] * df['ADANIENT']
    df['ATGL'] =data.iloc[1]['outstanding_shares'] * df['ATGL']
    df['ADANIGREEN'] =data.iloc[2]['outstanding_shares'] * df['ADANIGREEN']
    df['ADANIPORTS'] =data.iloc[3]['outstanding_shares'] * df['ADANIPORTS']
    df['ADANIPOWER'] =data.iloc[4]['outstanding_shares'] * df['ADANIPOWER']
    df['ADANITRANS'] =data.iloc[5]['outstanding_shares'] * df['ADANITRANS']
    df['RELIANCE']= (595523.60)*(1_00_00_000)
    df['total_marketcap'] = df.sum(axis=1)

    df['index'] =(df['total_marketcap']/df['total_marketcap'].iloc[0])*1000
    plt.title("ADANI-AMBANI INDEX")
    plt.plot(df['index'])
    plt.show()

    print(df)

adani_index()



# adani_ent = get_history(symbol="RELIANCE", start=date(2018,1,1), end=date(2021,2,18))['Close']
# print(adani_ent)
# plt.plot(adani_ent)
# plt.show()