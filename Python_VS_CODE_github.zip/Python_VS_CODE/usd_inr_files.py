import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import pandas_datareader as pdr
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
# import talib
import seaborn as sns
from statsmodels.tsa.stattools import adfuller
import statsmodels.api as sm  
from nsetools import Nse 
from nsepy.history import get_price_list
import time
import os
from dateutil.relativedelta import relativedelta

# df=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\For Ashish\merge_file\combine.csv",parse_dates=True, index_col=0) 
# df=df.drop(columns=['Unnamed: 9', 'Unnamed: 10', 'Unnamed: 11'])
# df=df[:-1]
# df['Contract'] = df.index

# df=df[[ 'Contract', 'Date', 'Time', 'Open', 'High', 'Low', 'Close', 'Volume',
#        'Open Interest']]

# condition =df['Date'] != 'Date'
# df=df[condition]
# df=df.reset_index(drop=True)
# df['Date_Time']= pd.to_datetime(df['Date'] + ' ' + df['Time'] )

# print(df)

# df.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\USD_INR_FILE\sorted_file_usdinr.csv")


# df=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\USD_INR_FILE\sorted_file_usdinr.csv", parse_dates=['Date'], dayfirst=True) 
# df=df.drop(columns=['Unnamed: 0'])
# df=df[['Contract', 'Date', 'Time','Date_Time' ,'Open', 'High', 'Low', 'Close', 'Volume','Open Interest']]
# df['New_date'] = pd.to_datetime(df['Date'])
# # df['New_date']

# # contract_list = df['Contract'].unique()
# df['contract_month'] = df['Contract'].str.slice(6, 11) 
 
# df['year'] = df['Date'].dt.year
# df['month'] = df['Date'].dt.month

# year = 2020
# start= '20'

# contract_list = ['JAN' ,'FEB' ,'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC']
# month = [1,2,3,4,5,6,7,8,9,10,11,12]

# new_contract_list=[]

# for i in range(len(contract_list)):

#     symbol=start + contract_list[i]
#     new_contract_list.append(symbol)

# print(new_contract_list)
# print(month)
# # print(df)

# contract_list=new_contract_list

# for i in range(12):

#     if  i ==0:

#         # print(i)
        
#         first_df=df.copy()

#         condition = first_df['contract_month'] ==contract_list[i]
#         first_df=first_df[condition]
#         first_df=first_df.reset_index(drop=True)

#         condition_3 = first_df['month'] == month[i]
#         first_df=first_df[condition_3]

#         condition_2 = first_df['year'] == year
#         first_df=first_df[condition_2]

#         date_list= first_df['Date'].unique()
#         first_df=first_df.reset_index(drop=True)

#     else:
   
#         second_df=df.copy()

#         condition = second_df['contract_month'] ==contract_list[i]
#         second_df=second_df[condition]
#         second_df=second_df.reset_index(drop=True)

#         condition_3 = second_df['month'] == month[i]
#         second_df=second_df[condition_3]

#         condition_2 = second_df['year'] == year
#         second_df=second_df[condition_2]

#         date_list= second_df['Date'].unique()
#         second_df=second_df.reset_index(drop=True)

#         result_df= pd.concat( [first_df, second_df ])

#         first_df= result_df
        

# result_df=result_df[['Contract', 'Date', 'Time' , 'Open', 'High', 'Low', 'Close' , 'Volume', 'Open Interest']]
# print(result_df)

# result_df.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\USD_INR_FILE\usd_inr_2020.csv")


df=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\usd_inr_2020.csv", parse_dates=['Date'], dayfirst=True)
print(df) 

# 12:29:59












