import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import pandas_datareader as pdr
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
# import talib
import seaborn as sns
from statsmodels.tsa.stattools import adfuller
import statsmodels.api as sm  
from nsetools import Nse 
import datetime 
from datetime import datetime, timedelta
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
from sklearn import preprocessing
from sklearn.neighbors import KNeighborsClassifier
from sklearn import metrics

# tick_data_1=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\nifty20072014.csv",parse_dates=True, index_col=0)
# tick_data_2 =pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\nifty20152020.csv",parse_dates=True, index_col=0)

# tick_data=pd.concat([ tick_data_1, tick_data_2])
# tick_data['result']=np.where(tick_data['Close'] > tick_data['Open'], 1 ,-1)
# tick_data['result']=tick_data['result'].shift(-1)
# tick_data=tick_data.reset_index(drop=True)
# tick_data=tick_data.dropna()
# print(tick_data)

tick_data=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\nifty20152020.csv",parse_dates=True, index_col=0)
tick_data['result']=np.where(tick_data['Close'] > tick_data['Open'], 1 ,-1) 
tick_data['result']=tick_data['result'].shift(-1)

tick_data=tick_data.reset_index(drop=True)
tick_data=tick_data.dropna()
# print(tick_data)

X=tick_data[['Open','High','Low','Close']].values
X=X/12000
y=tick_data['result'].values

print(X)
print(y)

X = preprocessing.StandardScaler().fit(X).transform(X.astype(float))
X_train, X_test, y_train, y_test = train_test_split( X, y, test_size=0.2, random_state=0)

print ('Train set:', X_train.shape,  y_train.shape)
print ('Test set:', X_test.shape,  y_test.shape)

Ks = 50
mean_acc = np.zeros((Ks-1))
std_acc = np.zeros((Ks-1))
ConfustionMx = [];

for n in range(1,Ks):
    
    #Train Model and Predict  
    neigh = KNeighborsClassifier(n_neighbors = n).fit(X_train,y_train)
    yhat=neigh.predict(X_test)
    mean_acc[n-1] = metrics.accuracy_score(y_test, yhat)

    std_acc[n-1]=np.std(yhat==y_test)/np.sqrt(yhat.shape[0])

print(mean_acc)

plt.figure(figsize=(10,6))
plt.plot(range(1,Ks),mean_acc,'g')
plt.fill_between(range(1,Ks),mean_acc - 1 * std_acc,mean_acc + 1 * std_acc, alpha=0.10)
plt.legend(('Accuracy ', '+/- 3xstd'))
plt.ylabel('Accuracy ')
plt.xlabel('Number of Nabors (K)')
plt.tight_layout()
plt.show()

print("Train set Accuracy: ", metrics.accuracy_score(y_train, neigh.predict(X_train)))
print( "The best accuracy was with", mean_acc.max(), "with k=", mean_acc.argmax()+1) 


# X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.9, random_state=0)

# model=keras.Sequential([
#         keras.layers.Dense(50, input_shape=(X.shape[1],), activation='relu'),
#         keras.layers.Dense(100, activation='sigmoid'),
#         keras.layers.Dense(50, activation='sigmoid')
#     ])

# model.compile(optimizer='adam',loss='binary_crossentropy',metrics=['accuracy'])

# model.fit(X_train,y_train, epochs=10)

# print(tick_data)



