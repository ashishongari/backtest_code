import pandas as pd  
import numpy as np  
import pandas_datareader as pdr
import matplotlib.pyplot as plt  
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
import seaborn as sns  
from nsetools import Nse 
import datetime as dt
from datetime import datetime
from datetime import timedelta

# def del_test(stock):
    
#     price=get_history(stock, start=date(2010,1,1), end=date.today())
#     print(price)
    
#     price_del_volumne=price['%Deliverble']*price['Turnover']
#     turnover =get_history(stock, start=date(2010,1,1), end=date.today())['Turnover']
#     turnover =turnover.rolling(window=30).mean()
#     price_del_volume=price_del_volumne.rolling(window=30).mean()
    
#     plt.plot(turnover, label='total_turnover')
#     plt.plot(price_del_volume, label='deliver_turnover')
#     plt.title(f"{stock}")
#     plt.legend()
#     plt.show()

# del_test('CHOLAFIN')

df=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\NIFTY_50.csv", index_col=0)

df['mavg'] =df['Close'].rolling(window=200).mean()

df['exp_cont'] =((df['Close']/df['mavg'])-1)*100

df=df.replace(np.nan, 0)

plt.plot(df['Close'])
plt.show()

print(df)

