import pandas as pd  
import numpy as np  
import pandas_datareader as pdr
import matplotlib.pyplot as plt  
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
import seaborn as sns  
from nsetools import Nse 
import datetime 
from datetime import datetime, timedelta
from nsepy.history import get_price_list
import pandas_datareader.data as web
from datetime import datetime, timedelta
import datetime

df=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\krishna_backtest.csv", index_col=0)
stock_list =list(df.index)
# print(stock_list)

ticker_list=[]

for i in range(len(stock_list)):
    end='.NS'
    symbol=stock_list[i] + end
    ticker_list.append(symbol)

print(ticker_list)

print(f"number of stocks is {len(ticker_list)}")

start = datetime.datetime(2013, 4, 1)
end = datetime.datetime(2021, 2, 25)

close_price = web.DataReader(ticker_list, 'yahoo', start, end)['Adj Close']
print(close_price)

close_price.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\equity_data_index.csv")
