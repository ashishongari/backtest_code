import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import pandas_datareader as pdr
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
# import talib
import seaborn as sns
from statsmodels.tsa.stattools import adfuller
import statsmodels.api as sm  
from nsetools import Nse 
from nsepy.history import get_price_list
import glob
import os


df=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\USD_INR_FILE\merged_df.csv",parse_dates=True, index_col=0) 
df['Date']=pd.to_datetime(df['Date'])

new_df=df.copy()
new_df=new_df.reset_index(drop=True)
mask = (new_df['Date'] >= '2019-2-1') & (new_df['Date'] <= '2019-2-28')
new_df = new_df.loc[mask]

new_df = new_df.loc[new_df['Ticker'] == 'USDINR19FEBFUT.CDS'] 

# new_df= new_df[new_df['Ticker'].str.contains('19FEB', regex=False)]

unique_date= new_df['Date'].unique()
print(f"unique dates is {len(unique_date)}")
print(new_df)

# df=df.reset_index(drop=True)
# mask = (df['Date'] >= '2019-2-1') & (df['Date'] <= '2019-2-28')
# df = df.loc[mask]
# unique_date= df['Date'].unique()
# print(f"unique dates is {len(unique_date)}")

# df.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\USD_INR_FILE\df.csv")

