import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
# import talib
import seaborn as sns
from scipy.stats import norm
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split 
from sklearn.metrics import mean_squared_error, r2_score
from sklearn import metrics
import scipy.optimize as opt
from sklearn.metrics import confusion_matrix 
from sklearn.metrics import accuracy_score
from sklearn import preprocessing
from sklearn.neighbors import KNeighborsClassifier
import glob
import numpy as np
import pandas as pd

path =r'C:\Users\DeepakShenoy\Desktop\Quantitative Research\glob_files\nifty'
filenames = glob.glob(path + "/*.csv")

dfs = []
for filename in filenames:
    dfs.append(pd.read_csv(filename))

big_frame = pd.concat(dfs, ignore_index=True)

big_frame=big_frame[['Date', 'Time', 'Open' , 'High' , 'Low' , 'Close']]

print(big_frame)