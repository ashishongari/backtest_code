import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import pandas_datareader as pdr
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
import talib
import seaborn as sns
from statsmodels.tsa.stattools import adfuller
import statsmodels.api as sm  
from nsetools import Nse 
import datetime 
from datetime import datetime, timedelta

nifty_index=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\NIFTY 50_Data.csv", index_col=0)['Close']
auto_index=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\NIFTY Auto_Data.csv", index_col=0)['Close']
bank_index=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\NIFTY Bank_Data.csv", index_col=0)['Close']
fmcg_index=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\NIFTY FMCG_Data.csv", index_col=0)['Close']
it_index=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\NIFTY IT_Data.csv", index_col=0)['Close']
media_index=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\NIFTY Media_Data.csv", index_col=0)['Close']
metal_index=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\NIFTY Metal_Data.csv", index_col=0)['Close']
pharma_index=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\NIFTY Pharma_Data.csv", index_col=0)['Close']
realty_index=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\NIFTY Realty_Data.csv", index_col=0)['Close']
commodity_index=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\NIFTY Commodities _Data.csv", index_col=0)['Close']
energy_index=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\NIFTY Energy_Data.csv", index_col=0)['Close']
infra_index=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\NIFTY Infrastructure _Data.csv", index_col=0)['Close']
oil_gas_index=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\NIFTY OIL & GAS_Data.csv", index_col=0)['Close']


df=pd.concat([nifty_index, auto_index, bank_index,fmcg_index,it_index,media_index, metal_index,pharma_index, realty_index,commodity_index, energy_index, infra_index, ], axis=1)
df['date'] =df.index
df=df.reset_index(drop=True)
df=df.sort_index(ascending=False)
df.columns=['nifty_index','auto_index','bank_index','fmcg_index','it_index', 'media_index', 'metal_index',  'pharma_index', 'realty_index', 'commodity_index', 'energy_index', 'infra_index','date']
df=df.reset_index(drop=True)
df=df.replace(np.nan, 0)
df=df[['date','nifty_index','auto_index','bank_index','fmcg_index','it_index', 'media_index', 'metal_index',  'pharma_index', 'realty_index', 'commodity_index', 'energy_index', 'infra_index']]
df['date']=pd.to_datetime(df['date'])
# print(df.dtypes)


df_plot=df[['date','nifty_index','auto_index','bank_index','fmcg_index','it_index', 'media_index', 'metal_index',  'pharma_index', 'realty_index', 'commodity_index', 'energy_index', 'infra_index']]

# df_plot['nifty_index']=( df_plot['nifty_index']/ df_plot['nifty_index'].iloc[0])*100
# df_plot['auto_index']=( df_plot['auto_index']/ df_plot['auto_index'].iloc[0])*100
# df_plot['bank_index']=( df_plot['bank_index']/ df_plot['bank_index'].iloc[0])*100
# df_plot['fmcg_index']=( df_plot['fmcg_index']/ df_plot['fmcg_index'].iloc[0])*100
# df_plot['fmcg_index']=( df_plot['fmcg_index']/ df_plot['fmcg_index'].iloc[0])*100
# df_plot['it_index']=( df_plot['it_index']/ df_plot['it_index'].iloc[0])*100
# df_plot['media_index']=( df_plot['media_index']/ df_plot['media_index'].iloc[0])*100
# df_plot['metal_index']=( df_plot['metal_index']/ df_plot['metal_index'].iloc[0])*100
# df_plot['pharma_index']=( df_plot['pharma_index']/ df_plot['pharma_index'].iloc[0])*100
# df_plot['realty_index']=( df_plot['realty_index']/ df_plot['realty_index'].iloc[0])*100
# df_plot['commodity_index']=( df_plot['commodity_index']/ df_plot['commodity_index'].iloc[0])*100
# df_plot['energy_index']=( df_plot['energy_index']/ df_plot['energy_index'].iloc[0])*100
# df_plot['infra_index']=( df_plot['infra_index']/ df_plot['infra_index'].iloc[0])*100
# df_plot=df_plot.replace(np.nan,0)
# df_plot=df_plot.replace([np.inf, -np.inf], 0)
# print(df_plot)


plt.plot(df['date'], df_plot['nifty_index'], label='nifty_index')
plt.plot(df['date'], df_plot['auto_index'], label='auto_index')
plt.plot(df['date'], df_plot['bank_index'], label='bank_index')
plt.plot(df['date'], df_plot['fmcg_index'], label='fmcg_index')
# plt.plot(df['date'], df_plot['it_index'], label='it_index')
plt.plot(df['date'], df_plot['media_index'], label='media_index')
plt.plot(df['date'], df_plot['metal_index'], label='metal_index')
plt.plot(df['date'], df_plot['pharma_index'], label='pharma_index')
plt.plot(df['date'], df_plot['realty_index'], label='realty_index')
plt.plot(df['date'], df_plot['commodity_index'], label='commodity_index')
plt.plot(df['date'], df_plot['energy_index'], label='energy_index')
plt.plot(df['date'], df_plot['infra_index'], label='infra_index')
plt.legend()
plt.show()




