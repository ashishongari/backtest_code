from datetime import datetime, date, timedelta
import pandas as pd
import requests
import time
from bs4 import BeautifulSoup




# def fetch_prices(symbol):    
#     froms = pd.date_range(start='1/1/2016', end='12/24/2020', freq='1M').tolist()
#     froms = [d.date() for d in froms]
#     tos = [d - timedelta(days=1) for d in froms][1:] + [date.today()]
#     data = pd.DataFrame(columns=['Date', 'Close', 'Open' ,'High', 'Low', 'Volume'])
#     for from_date, to_date in list(zip(froms, tos)):
#         url = "https://tvc4.forexpros.com/41b43920de89d45218703734672d2a06/1608641691/1/1/8/history?"
#         headers = {'user-agent': 'Mozilla/5.0'}
#         params = {
#             'symbol': symbol,
#             'resolution': '60',
#             'from': int(time.mktime(from_date.timetuple())),
#             'to': int(time.mktime(to_date.timetuple()))
#         }
#         r = requests.get(url, headers=headers, params=params)
#         print(r.status_code, from_date, to_date)
#         resp = r.json()

#         print(resp)
#         dates = [datetime.fromtimestamp(t) for t in resp['t']]
#         Close = resp['c']
#         Open = resp['o']
#         High = resp['h']
#         Low = resp['l']
#         Volume = resp['v']
#         data = pd.concat([data, pd.DataFrame({'Date': dates, 'Close': Close , 'Open': Open, 'High' : High , 'Low' : Low , 'Volume' : Volume})])

#     return data

# if __name__=='__main__':

#     df=fetch_prices(179)
    # df.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Equity_Strategy_Backtest\hong_kong.csv")




# https://tvc4.forexpros.com/41b43920de89d45218703734672d2a06/1608641691/1/1/8/history?symbol=101810&resolution=D&from=1577537697&to=1608641757

#HANG SENG
# https://tvc6.forexpros.com/eb2796bb894d141edd15fcf086a4c322/1609004348/1/1/8/history?symbol=8984&resolution=D&from=1577900398&to=1609004458


#sp500
# https://tvc6.forexpros.com/f06d4a4e677acfcaa1c78ce341d60b95/1609004580/1/1/8/history?symbol=8839&resolution=D&from=1577900608&to=1609004668


#HONG_KONG
# https://tvc4.forexpros.com/3702fd226eeac2f36468829b361af3e2/1610433486/1/1/8/history?symbol=179&resolution=5&from=1609949519&to=1610001579



# https://query1.finance.yahoo.com/v7/finance/download/RELIANCE.NS? period1=1580814780&period2=1612437180&interval=1d&events=history&includeAdjustedClose=true


stock_code='SBIN'

# ts1=
# ts2= 

interval ='1d'
# interval='1wk'
# interval ='1mo'

events='history'
# events='div'

url =  'https://query1.finance.yahoo.com/v7/finance/download/'+stock_code+'.NS?period1=1580814780&period2=1612437180&interval='+interval+'&events='+events+'&includeAdjustedClose=true'
print(url)






