import pdb
import pandas as pd
import matplotlib.pyplot as plt  
# import kite_logging
from datetime import datetime, timedelta
from kiteconnect import KiteConnect
from kite_logging import kite


traded_portfolio ={'HDFC' : {'token':340481}}

token =340481
to_date =datetime.now()
from_date= to_date -timedelta(days=60)
interval ='minute'
        
first_df =  kite.historical_data(token, from_date, to_date, interval)
first_df=pd.DataFrame(first_df)
print(first_df.head(50))

