import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import pandas_datareader as pdr
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
import talib
import seaborn as sns
from statsmodels.tsa.stattools import adfuller
import statsmodels.api as sm  
from nsetools import Nse 
import datetime 
from datetime import datetime, timedelta

nse = Nse()
lot_size_dict=nse.get_fno_lot_sizes()
df = pd.DataFrame(list(lot_size_dict.items()),columns = ['stock','lot'])
list_stock=np.array(df['stock'])
# print(len(list_stock))

stock_name=[]
mtm=[]

def new_short_sell_algo():

    for j in range(2,len(list_stock)-1):

        from nsetools import Nse 
        nse = Nse()
        lot_size_dict=nse.get_fno_lot_sizes()

        lot_size=lot_size_dict[list_stock[j]]

        end='.NS'
        symbol=list_stock[j] + end
        
        data = pdr.get_data_yahoo(symbol, start=datetime(2008, 1, 1), end=datetime.today())[['Open','Close']]

        data['prev_price']=data['Close'].shift(1)
        data['change']=data['Close'].sub(data['prev_price'])
        data['lot_size']=lot_size
        data['running_max']=data['Close'].expanding().max()
        data['short_sell']=data['running_max']*(0.75)
        data['bottom_price']=data['Close'].rolling(window=252).min()
        data['exit_price']=data['bottom_price'] + (abs(data['bottom_price'])*0.35)
        data=data.dropna()

        # plt.plot(data['Close'])
        # plt.plot(data['short_sell'])
        # plt.plot( data['exit_price'])
        # plt.show()

        data['sell_entry']=np.where( data['Close'] < data['short_sell'] ,1,0)
        data['sell_exit']=np.where(  data['Close'] > data['exit_price'] ,1,0)

        data['sell_position']=0

        for i in range(len(data)):
            
            if data['sell_entry'].iloc[i] ==1 and data['sell_exit'].iloc[i] ==0:
                
                data['sell_position'].iloc[i]='position_live'
                    
            else :
                
                data['sell_position'].iloc[i]='no_position' 
        
        data['sell_position']=data['sell_position'].shift(1)

        data['MTM']=0

        for i in range(len(data)):

            if data['sell_position'].iloc[i]=='position_live':

                data['MTM'].iloc[i] = data['change'].iloc[i]*lot_size*(-1)
            else:

                data['MTM'].iloc[i] =0

        # print(f" MTM of {list_stock[i]} is {data['MTM'].sum(axis=0)}")

        profit_loss=data['MTM'].sum(axis=0)

        # data['margin']=0

        # for i in range(len(data)):

        #     if i==0:

        #         data['margin'].iloc[i]=10_00_000

        #     elif  data['sell_position'].iloc[i]=='position_live':

        #         data['margin'].iloc[i] = data['margin'].iloc[i-1] + data['MTM'].iloc[i]
            
        #     else:
        #         data['margin'].iloc[i] = data['margin'].iloc[i-1  ]


        stock_name.append(list_stock[j])
        mtm.append(profit_loss)
        # plt.plot(data['margin'])
        # plt.title(f"Equity Curve OF {ticker}")
        # plt.show()

        # data.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\itc_short_sell.csv")

    return 

new_short_sell_algo()

# print(stock_name)
# print(mtm)

stock_name=pd.DataFrame(stock_name)
mtm=pd.DataFrame(mtm)
backtest_df=pd.concat([stock_name, mtm], axis=1)
backtest_df.columns=['stock_name','mtm']
print(backtest_df)

backtest_df.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\backtest_df_short_sell.csv")