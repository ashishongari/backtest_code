import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import pandas_datareader as pdr
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
import talib
import seaborn as sns
from statsmodels.tsa.stattools import adfuller
import statsmodels.api as sm  
from nsetools import Nse 
import datetime 
from datetime import datetime, timedelta


# def mean_reversion_simple(freq_day):
    
#     close_price=pdr.get_data_yahoo('^NSEI', start=datetime(2005, 1, 1), end=datetime.today())[['High','Low','Open','Adj Close']]
#     # close_price=pd.DataFrame(close_price)
#     # close_price.columns=['close']

#     close_price['prev_close']=close_price['Adj Close'].shift(1)
#     close_price['diff']=close_price['Adj Close'].sub(close_price['prev_close'])
#     # close_price['diff']=close_price['diff'].shift(1)

#     close_price['moving_mean']=close_price['diff'].rolling(window=freq_day).mean()
#     close_price['moving_std']=close_price['diff'].rolling(window=freq_day).std()
#     close_price['zscore']=(close_price['diff']-close_price['moving_mean']).div(close_price['moving_std'])
#     close_price= close_price.replace(np.nan,0)

#     close_price['signal_price']=(close_price['High'] + close_price['Low'] + close_price['Open']).div(3)

#     close_price['signal_price_diff']=close_price['Adj Close'] - close_price['signal_price']

#     plt.plot(close_price['zscore'])
#     plt.show()

#     close_price=close_price.copy().dropna()

#     close_price['z_signal_buy_entry']=np.where( close_price['zscore'] >=2.0,1,0)

#     close_price['buy_exit']=np.where( close_price['zscore'] <0 ,1,0)

#     close_price['buy_position']=0

#     for i in range(len(close_price)):
        
#         if (close_price['z_signal_buy_entry'].iloc[i] ==0 and close_price['buy_exit'].iloc[i] ==1) and (close_price['buy_position'].iloc[i-1] =='postion_live'):
            
#             close_price['buy_position'].iloc[i]='no_position'
            
#         elif (close_price['z_signal_buy_entry'].iloc[i] ==1 and close_price['buy_exit'].iloc[i] ==0) or (close_price['buy_position'].iloc[i-1] =='postion_live') :
            
#             close_price['buy_position'].iloc[i]='postion_live'
                
#         else :
            
#             close_price['buy_position'].iloc[i]='no_position'


#     close_price['z_signal_sell_entry']=np.where( close_price['zscore']  <=-2.0,1,0)

#     close_price['sell_exit']=np.where( close_price['zscore'] >0 ,1,0)

#     close_price['sell_position']=0

#     for i in range(len(close_price)):
        
#         if (close_price['z_signal_sell_entry'].iloc[i] ==0 and close_price['sell_exit'].iloc[i] ==1) and (close_price['sell_position'].iloc[i-1] =='postion_live'):
            
#             close_price['sell_position'].iloc[i]='no_position'
            
#         elif (close_price['z_signal_sell_entry'].iloc[i] ==1 and close_price['sell_exit'].iloc[i] ==0) or (close_price['sell_position'].iloc[i-1] =='postion_live') :
            
#             close_price['sell_position'].iloc[i]='postion_live'
                
#         else :
            
#             close_price['sell_position'].iloc[i]='no_position'

#     close_price['upper_signal']=np.where( close_price['buy_position']=='postion_live', 1 , 0)
#     close_price['lower_signal']=np.where( close_price['sell_position']=='postion_live', -1 , 0)

#     close_price['final_signal']=close_price['upper_signal'].add(close_price['lower_signal'])
#     close_price['final_signal']=close_price['final_signal'].shift(1)

#     close_price['mtm']=0

#     for i in range(len(close_price)):

#         if close_price['final_signal'].iloc[i]==1:

#             close_price['mtm'].iloc[i] =  ((close_price['diff'].iloc[i])*(75)) - 90
        
#         elif close_price['final_signal'].iloc[i]==-1:

#             close_price['mtm'].iloc[i] =   ((close_price['diff'].iloc[i])*(-75)) -90
            
#         else:
#             close_price['mtm'].iloc[i] = 0

#     print(close_price['mtm'].sum(axis=0))
#     print(close_price.head(50))

#     close_price['margin']=1_00_000

#     for i in range(len(close_price)):

#         close_price['margin'].iloc[i]= close_price['margin'].iloc[i-1] + close_price['mtm'].iloc[i]

#     plt.plot(close_price['margin'])
#     plt.show()

#     return

# mean_reversion_simple(50)


# def mean_reversion_new(freq_day):

#     df=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\close_price.csv", index_col=0)
#     df=df.replace(np.nan, 0)

#     df_diff=df.pct_change()
#     df_diff=df_diff.replace(np.nan, 0)

#     df_diff_mean=df_diff.mean(axis=1)
#     df_diff_mean=df_diff_mean.replace(np.nan, 0)
#     df_diff_mean=df_diff_mean[:-1]
#     df_diff_mean=pd.DataFrame(df_diff_mean)
#     df_diff_mean.columns=['data']
#     df_diff_mean['date']=df_diff_mean.index
#     df_diff_mean=df_diff_mean.reset_index(drop=True)
#     df_diff_mean['date']=pd.to_datetime(df_diff_mean['date'])
#     print(df_diff_mean)

#     # plt.plot( df_diff_mean['data'])
#     # plt.show()
    
#     # df_diff_mean.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Equity_Strategy_Backtest\df_diff_mean.csv")

#     return 

# mean_reversion_new(5)

# def nifty_gap_data():
    
#     close_price=pdr.get_data_yahoo('^NSEI', start=datetime(2005, 1, 1), end=datetime.today())[['High', 'Low', 'Open', 'Close', 'Adj Close']]
#     close_price['Date']=close_price.index
#     close_price=close_price.reset_index(drop=True)
#     close_price=close_price[['Date','High', 'Low', 'Open', 'Adj Close']]

#     close_price['gap']=0

#     for i in range(len(close_price)):

#         if i ==0:

#             close_price['gap'].iloc[i] =0

#         else:

#             close_price['gap'].iloc[i]=close_price['Open'].iloc[i] - close_price['Adj Close'].iloc[i-1]

#     # condition= close_price['gap'] > 0
#     # close_price=close_price[condition]

#     close_price['streak']=0

#     for i in range(len(close_price)):
        
#         if (close_price['gap'].iloc[i] > 0) and (close_price['gap'].iloc[i-1] > 0) :

#             close_price['streak'].iloc[i] =  close_price['streak'].iloc[i-1] + 1
        
#         else:
#             close_price['streak'].iloc[i]=1

#     # close_price.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Equity_Strategy_Backtest\nifty_gap_up_data.csv")

#     print(close_price)

#     return

# nifty_gap_data()



def nifty_gap_data():
    
    close_price=pdr.get_data_yahoo('^NSEI', start=datetime(2005, 1, 1), end=datetime.today())[['High', 'Low', 'Open', 'Close', 'Adj Close']]
    close_price['Date']=close_price.index
    close_price=close_price.reset_index(drop=True)
    close_price=close_price[['Date','High', 'Low', 'Open', 'Adj Close']]

    close_price['gap']=0

    for i in range(len(close_price)):

        if i ==0:

            close_price['gap'].iloc[i] =0

        else:

            close_price['gap'].iloc[i]=close_price['Open'].iloc[i] - close_price['Adj Close'].iloc[i-1]

    # close_price['']
    # condition= close_price['gap'] > 0
    # # close_price=close_price[condition]

    # close_price['streak']=0

    # for i in range(len(close_price)):
        
    #     if (close_price['gap'].iloc[i] > 0) and (close_price['gap'].iloc[i-1] > 0) :

    #         close_price['streak'].iloc[i] =  close_price['streak'].iloc[i-1] + 1
        
    #     else:
    #         close_price['streak'].iloc[i]=1

    # # close_price.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Equity_Strategy_Backtest\nifty_gap_up_data.csv")

    print(close_price)

    return

nifty_gap_data()












