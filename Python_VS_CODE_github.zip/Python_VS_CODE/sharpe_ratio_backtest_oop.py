import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import pandas_datareader as pdr
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
import talib
import seaborn as sns
from statsmodels.tsa.stattools import adfuller
import statsmodels.api as sm  
from nsetools import Nse 
import datetime 
from datetime import datetime, timedelta

def moving_sharpe_ratio_backtest(day):

    
    df=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\stock_data_F&O.csv", index_col=0)

    # df_pct=pd.DataFrame()

    def paramters():
        
        df_pct=df.pct_change()
        df_pct_sum=df_pct.rolling(window=day).sum()
        df_std=df_pct.rolling(window=day).std()
        df_sharpe_ratio=df_pct_sum.div(df_std)
        date_set=df_sharpe_ratio.index
        # print(df_sharpe_ratio)

        date_set=date_set[day:]
        date_set_df=pd.DataFrame(date_set)
        date_set_df.columns=['date']
        date_set_df['trading_day']=0
        
        return df_sharpe_ratio, date_set_df

    paramters()

    df_sharpe_ratio=paramters()
    print(df_sharpe_ratio)

    date_set_df=paramters()
    

    ########################################################################################################################################################

    """
    Define Buy and exit trading day for system
    """

    for i in range(len(date_set_df)):
        
        if i%25 ==0:
            date_set_df['trading_day'].iloc[i]=date_set_df['date'].iloc[i]
           
        else:
            date_set_df['trading_day'].iloc[i]=0
            

    condition=date_set_df['trading_day'] !=0
    date_set_df=date_set_df[condition]

    print(date_set_df) 



    return



moving_sharpe_ratio_backtest(30)



