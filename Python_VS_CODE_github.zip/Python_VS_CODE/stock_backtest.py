import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import pandas_datareader as pdr
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import calendar
import datetime as dt
from nsetools import Nse
import talib
import seaborn as sns
import time
import threading
from time import perf_counter
import concurrent.futures
import multiprocessing
import datetime 
from datetime import datetime, timedelta


# def data_base():
    
#     short_sell_df = pd.read_csv(r'C:\Users\DeepakShenoy\Desktop\Quantitative Research\Sharpe Short\short_sell_data.csv')
#     short_sell_df=short_sell_df.drop("CENTURYTEX", axis='columns')
#     short_sell_df=short_sell_df.drop("EQUITAS", axis='columns')
#     short_sell_df=short_sell_df.drop("CESC", axis='columns')
#     short_sell_df=short_sell_df.drop("JUSTDIAL", axis='columns')
#     short_sell_df=short_sell_df.drop("NCC", axis='columns')
#     short_sell_df=short_sell_df.drop("NIITTECH", axis='columns')
#     short_sell_df=short_sell_df.drop("UJJIVAN", axis='columns')
#     short_sell_df=short_sell_df[0:2149]
    
#     return short_sell_df

##############################################################################
#STOCK_PRICES_NAMES
# data=data_base()
# current_set=data.iloc[0]
# date_set=current_set[0]
# # print(date_set)

# current_set=current_set[1:len(current_set)]

# stock_name=current_set.index
# stock_name=pd.DataFrame(stock_name)

# stock_price=current_set.reset_index(drop=True)
# stock_price=pd.DataFrame(stock_price)

# live_date=pd.concat([stock_name,stock_price], axis=1)
# live_date.columns=['stock','price']
# # print(live_date)

# live_date=live_date.sort_values(by=['price'], ascending=False)
# live_date=live_date.reset_index(drop=True)
# print(live_date)

###############################################################################




