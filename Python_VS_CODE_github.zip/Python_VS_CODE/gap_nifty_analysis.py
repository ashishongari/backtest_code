import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import pandas_datareader as pdr
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
# import talib
import seaborn as sns
from statsmodels.tsa.stattools import adfuller
import statsmodels.api as sm  
from nsetools import Nse 
import datetime 
from datetime import datetime, timedelta

# def gap_up_long_down_short():
    
#     tick_data_1=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\nifty20072014.csv",parse_dates=True, index_col=0)
#     tick_data_2 =pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\nifty20152020.csv",parse_dates=True, index_col=0)
#     tick_data=pd.concat([ tick_data_1, tick_data_2])

#     date_df=tick_data_2['Date'].unique()
#     open_price=[]
#     close_price=[]
#     prev_close=[]
#     date_array_next_day=[]
#     date_array_prev_day=[]
#     trade_price=[]

#     for i in range(1, len(date_df)):
#         sample_df=tick_data.copy()
#         sample_df=sample_df.loc[sample_df['Date'] ==date_df[i]]
#         sample_df_price=sample_df['Open']
#         sample_df_price=sample_df_price.reset_index(drop=True)

#         open_price.append(sample_df_price.iloc[0])
#         close_price.append(sample_df_price.iloc[-1])
#         trade_price.append(sample_df_price.iloc[1])
#         date_array_next_day.append(date_df[i])


#     for i in range(0,len(date_df)):
#         sample_df=tick_data.copy()
#         sample_df=sample_df.loc[sample_df['Date']==date_df[i]]
#         sample_df_price=sample_df['Open']
#         sample_df_price=sample_df_price.reset_index(drop=True)

#         prev_close.append(sample_df_price.iloc[-1])
#         date_array_prev_day.append(date_df[i])

#     date_array_prev_day=pd.DataFrame(date_array_prev_day)
#     date_array_next_day=pd.DataFrame(date_array_next_day)
#     open_price=pd.DataFrame(open_price)
#     close_price=pd.DataFrame(close_price)
#     prev_close=pd.DataFrame(prev_close)
#     trade_price=pd.DataFrame(trade_price)

#     backtest_df=pd.concat([date_array_prev_day, prev_close, date_array_next_day,open_price,trade_price,close_price], axis=1)
#     backtest_df.columns=['date_array_prev_day', 'prev_close','date_array_next_day','open_price','trade_price','close_price']
#     backtest_df['signal']=np.where(backtest_df['open_price'] > backtest_df['prev_close'], 1, -1 )

#     backtest_df['change']=0

#     for i in range(len(backtest_df)):
        
#         if backtest_df['signal'].iloc[i]==1:

#             backtest_df['change'].iloc[i] = backtest_df['close_price'].iloc[i] - backtest_df['trade_price'].iloc[i]
        
#         elif backtest_df['signal'].iloc[i]==-1:

#             backtest_df['change'].iloc[i] = backtest_df['trade_price'].iloc[i] - backtest_df['close_price'].iloc[i]

#         else:
#             backtest_df['change'].iloc[i]=0

#     backtest_df['margin']=0

#     backtest_df=backtest_df.dropna()

#     for i in range(len(backtest_df)):
        
#         if i ==0:
            
#             backtest_df['margin'].iloc[i] = 8_00_000

#         else:
#             backtest_df['margin'].iloc[i] = (backtest_df['change'].iloc[i]*75) +  backtest_df['margin'].iloc[i-1]


#     print(backtest_df)
#     plt.plot(backtest_df['margin'])
#     plt.title("Equity Curve")
#     plt.show()

#     window = 50
#     Roll_Max_portfolio = backtest_df['margin'].rolling(window, min_periods=1).max()
#     Daily_Drawdown_portfolio = (backtest_df['margin']/Roll_Max_portfolio - 1)*100

#     max_return=backtest_df['change'].max()*(75)
#     min_return=backtest_df['change'].min()*(75)

#     backtest_df['result'] =np.where( backtest_df['change'] > 0, 1 ,-1)

#     positive_condition=backtest_df['result'] ==1
#     backtest_df_positive = backtest_df[positive_condition]

#     neagtive_condition=backtest_df['result'] == -1
#     backtest_df_negative = backtest_df[neagtive_condition]

#     print(f"max_return is {max_return} ")
#     print(f"min_return is {min_return}")
#     print(f"No of Positive days is {backtest_df_positive['result'].sum(axis=0)}")
#     print(f"No of Negative days is {backtest_df_negative['result'].sum(axis=0)*(-1)}")
#     print(f"Max Drawdown is {Daily_Drawdown_portfolio.min()}")

#     plt.plot(Daily_Drawdown_portfolio, color="blue", label="PORTFOLIO")
#     plt.title("DRAWDOWN")
#     plt.legend()
#     plt.show()

#     return

# gap_up_long_down_short()
    
# def gap_up_short_down_long():
    
#     tick_data_1=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\nifty20072014.csv",parse_dates=True, index_col=0)
#     tick_data_2 =pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\nifty20152020.csv",parse_dates=True, index_col=0)
#     tick_data=pd.concat([ tick_data_1, tick_data_2])

#     date_df=tick_data_2['Date'].unique()
#     open_price=[]
#     close_price=[]
#     prev_close=[]
#     date_array_next_day=[]
#     date_array_prev_day=[]
#     trade_price=[]

#     for i in range(1, len(date_df)):

#         sample_df=tick_data.copy()
#         sample_df=sample_df.loc[sample_df['Date'] ==date_df[i]]
#         sample_df_price=sample_df['Open']
#         sample_df_price=sample_df_price.reset_index(drop=True)

#         open_price.append(sample_df_price.iloc[0])
#         close_price.append(sample_df_price.iloc[-1])
#         trade_price.append(sample_df_price.iloc[1])
#         date_array_next_day.append(date_df[i])


#     for i in range(0,len(date_df)):

#         sample_df=tick_data.copy()
#         sample_df=sample_df.loc[sample_df['Date']==date_df[i]]
#         sample_df_price=sample_df['Open']
#         sample_df_price=sample_df_price.reset_index(drop=True)

#         prev_close.append(sample_df_price.iloc[-1])
#         date_array_prev_day.append(date_df[i])

#     date_array_prev_day=pd.DataFrame(date_array_prev_day)
#     date_array_next_day=pd.DataFrame(date_array_next_day)
#     open_price=pd.DataFrame(open_price)
#     close_price=pd.DataFrame(close_price)
#     prev_close=pd.DataFrame(prev_close)
#     trade_price=pd.DataFrame(trade_price)

#     backtest_df=pd.concat([date_array_prev_day, prev_close, date_array_next_day,open_price,trade_price,close_price], axis=1)
#     backtest_df.columns=['date_array_prev_day', 'prev_close','date_array_next_day','open_price','trade_price','close_price']
#     backtest_df['signal']=np.where(backtest_df['open_price'] > backtest_df['prev_close'], 1, -1 )

#     backtest_df['change']=0

#     for i in range(len(backtest_df)):
        
#         if backtest_df['signal'].iloc[i]==1:

#             backtest_df['change'].iloc[i] =  backtest_df['trade_price'].iloc[i] -backtest_df['close_price'].iloc[i]
        
#         elif backtest_df['signal'].iloc[i]==-1:

#             backtest_df['change'].iloc[i] =  backtest_df['close_price'].iloc[i] - backtest_df['trade_price'].iloc[i]

#         else:
#             backtest_df['change'].iloc[i]=0

#     backtest_df['margin']=0

#     backtest_df=backtest_df.dropna()

#     for i in range(len(backtest_df)):
        
#         if i ==0:
            
#             backtest_df['margin'].iloc[i] = 8_00_000

#         else:
#             backtest_df['margin'].iloc[i] = (backtest_df['change'].iloc[i]*75) +  backtest_df['margin'].iloc[i-1]


#     print(backtest_df)
#     plt.plot(backtest_df['margin'])
#     plt.title("Equity Curve")
#     plt.show()

#     window = 50
#     Roll_Max_portfolio = backtest_df['margin'].rolling(window, min_periods=1).max()
#     Daily_Drawdown_portfolio = (backtest_df['margin']/Roll_Max_portfolio - 1)*100

#     max_return=backtest_df['change'].max()*(75)
#     min_return=backtest_df['change'].min()*(75)
    
#     backtest_df['result'] =np.where( backtest_df['change'] > 0, 1 ,-1)

#     positive_condition=backtest_df['result'] ==1
#     backtest_df_positive = backtest_df[positive_condition]
    
#     neagtive_condition=backtest_df['result'] == -1
#     backtest_df_negative = backtest_df[neagtive_condition]
    
#     print(f"max_return is {max_return} ")
#     print(f"min_return is {min_return}")
#     print(f"No of Positive days is {backtest_df_positive['result'].sum(axis=0)}")
#     print(f"No of Negative days is {backtest_df_negative['result'].sum(axis=0)*(-1)}")
#     print(f"Max Drawdown is {Daily_Drawdown_portfolio.min()}")

#     plt.plot(Daily_Drawdown_portfolio, color="blue", label="PORTFOLIO")
#     plt.title("DRAWDOWN")
#     plt.legend()
#     plt.show()

#     return

# gap_up_short_down_long()


nifty  = pdr.get_data_yahoo('^NSEI', start=datetime(2007, 1, 1), end=datetime.today())[['High', 'Low', 'Open','Adj Close']] 
nifty['Date']=nifty.index
nifty=nifty.reset_index(drop=True)
nifty=nifty[['Date','High', 'Low', 'Open','Adj Close']] 
    
nifty['high_low']=0
nifty['gap']=0

for i in range(len(nifty)):
    if i==0:
        nifty['gap'].iloc[i]=0
        nifty['high_low'].iloc[i]=0
    else:
        nifty['high_low'].iloc[i]=(nifty['Adj Close'].iloc[i] - nifty['Open'].iloc[i])
        nifty['gap'].iloc[i] =(nifty['Open'].iloc[i] - nifty['Adj Close'].iloc[i-1])

print(f"Nifty Bank Cummulative Intraday Movement is {nifty['high_low'].sum(axis=0)}")
print(f"Nifty Bank Cummulative Gap Movement is {nifty['gap'].sum(axis=0)}")








