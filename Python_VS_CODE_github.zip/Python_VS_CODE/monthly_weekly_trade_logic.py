import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import pandas_datareader as pdr
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import calendar
import datetime as dt
from nsetools import Nse
import talib
import seaborn as sns
from scipy.stats import norm
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split 
from sklearn.metrics import mean_squared_error, r2_score
from sklearn import metrics
import scipy.optimize as opt
from sklearn.metrics import confusion_matrix 
from sklearn.metrics import accuracy_score
from sklearn import preprocessing
from sklearn.neighbors import KNeighborsClassifier
import time
import threading
from time import perf_counter
import concurrent.futures
import multiprocessing
from dateutil.relativedelta import relativedelta
import datetime 
from datetime import datetime, timedelta
"""
Go Long on Nifty if Friday's 3.15 PM  Close > 9.16 AM Open else Short and exit on Monday 9.16 AM

"""

# def nifty_open(lot_size):
    
#     data_1=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\nifty20072014.csv",parse_dates=True, index_col=0)
#     # data_1=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\nifty20152020.csv",parse_dates=True, index_col=0)

#     date_data=data_1['Date'].unique()
#     date_df=pd.DataFrame(date_data)
#     date_df.columns=['Date']

#     date_df['weekday_name']=0

#     for i in range(len(date_df)):
        
#         born = datetime.datetime.strptime(date_df['Date'].iloc[i], '%d-%m-%Y').weekday() 
#         date_df['weekday_name'].iloc[i]=calendar.day_name[born]

    
#     date_df['Trading_day']=0
#     date_df['Next_day']=0

#     for i in range(len(date_df)-1):

#         if date_df['weekday_name'].iloc[i]=='Friday':

#             date_df['Trading_day'].iloc[i] = date_df['Date'].iloc[i]
#             date_df['Next_day'].iloc[i] = date_df['Date'].iloc[i+1]
#         else:
#             date_df['Trading_day'].iloc[i] = 0
#             date_df['Next_day'].iloc[i] = 0
        
#     condition=date_df['Trading_day'] != 0
#     date_df=date_df[condition]

#     date_df=date_df[['Trading_day','Next_day']]
#     date_df=date_df.reset_index(drop=True)

#     date_df['trading_day_open']=0
#     date_df['trading_day_close']=0
#     date_df['next_day_open']=0

#     for i in range(len(date_df)):
        
#         live_data_trading_data=data_1.loc[data_1['Date']==date_df['Trading_day'][i]]
#         live_data_next_data=data_1.loc[data_1['Date']==date_df['Next_day'][i]]
#         print(live_data_trading_data)

#         trading_day_open =live_data_trading_data['Open'][1]
#         trading_day_close =live_data_trading_data['Close'][-15]

#         next_day_open=live_data_next_data['Close'][1]

#         date_df['trading_day_open'].iloc[i]=trading_day_open
#         date_df['trading_day_close'].iloc[i]=trading_day_close
#         date_df['next_day_open'].iloc[i]=next_day_open


#     date_df['Short_Long'] =np.where( date_df['trading_day_close'] >  date_df['trading_day_open'], 1, -1)

#     date_df['MTM']=0

#     for i in  range(len(date_df)):

#         if date_df['Short_Long'].iloc[i]==1:

#             date_df['MTM'].iloc[i] = (date_df['next_day_open'].iloc[i] - date_df['trading_day_close'].iloc[i])*lot_size

#         elif date_df['Short_Long'].iloc[i]== -1:

#             date_df['MTM'].iloc[i] = ((date_df['next_day_open'].iloc[i] - date_df['trading_day_close'].iloc[i])*lot_size)*(-1)

#         else:
#             date_df['MTM'].iloc[i]=0

#     print(f"MTM of strategy is {date_df['MTM'].sum()}")
#     # print( date_df)
#     # date_df.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\date_df_monday_open_2007_2015.csv")

#     return
    
# nifty_open(25)

# ############################################################################################################################################


# """
# Go Long on Nifty if Friday's 3.15 PM  Close > 9.16 AM Open else Short and exit on Monday 3.15 PM

# """
# def nifty_close(lot_size):
    
#     data_1=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\nifty20072014.csv",parse_dates=True, index_col=0)
#     # data_1=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\nifty20152020.csv",parse_dates=True, index_col=0)

#     date_data=data_1['Date'].unique()
#     date_df=pd.DataFrame(date_data)
#     date_df.columns=['Date']

#     date_df['weekday_name']=0

#     for i in range(len(date_df)):
        
#         born = datetime.datetime.strptime(date_df['Date'].iloc[i], '%d-%m-%Y').weekday() 
#         date_df['weekday_name'].iloc[i]=calendar.day_name[born]

#     date_df['Trading_day']=0
#     date_df['Next_day']=0

#     for i in range(len(date_df)):

#         if date_df['weekday_name'].iloc[i]=='Friday':

#             date_df['Trading_day'].iloc[i] = date_df['Date'].iloc[i]
#             date_df['Next_day'].iloc[i] = date_df['Date'].iloc[i+1]
#         else:
#             date_df['Trading_day'].iloc[i] = 0
#             date_df['Next_day'].iloc[i] = 0
        
#     condition=date_df['Trading_day'] != 0
#     date_df=date_df[condition]

#     date_df=date_df[['Trading_day','Next_day']]
#     date_df=date_df.reset_index(drop=True)

#     date_df['trading_day_open']=0
#     date_df['trading_day_close']=0
#     date_df['next_day_open']=0

#     for i in range(len(date_df)):
        
#         live_data_trading_data=data_1.loc[data_1['Date']==date_df['Trading_day'][i]]
#         live_data_next_data=data_1.loc[data_1['Date']==date_df['Next_day'][i]]
#         print(live_data_trading_data)

#         trading_day_open =live_data_trading_data['Open'][1]
#         trading_day_close =live_data_trading_data['Close'][-15]

#         next_day_open=live_data_next_data['Close'][-15]

#         date_df['trading_day_open'].iloc[i]=trading_day_open
#         date_df['trading_day_close'].iloc[i]=trading_day_close
#         date_df['next_day_open'].iloc[i]=next_day_open

#     date_df['Short_Long'] =np.where( date_df['trading_day_close'] >  date_df['trading_day_open'], 1, -1)
#     date_df['MTM']=0


#     for i in  range(len(date_df)):

#         if date_df['Short_Long'].iloc[i]==1:

#             date_df['MTM'].iloc[i] = (date_df['next_day_open'].iloc[i] - date_df['trading_day_close'].iloc[i])*lot_size

#         elif date_df['Short_Long'].iloc[i]== -1:

#             date_df['MTM'].iloc[i] = ((date_df['next_day_open'].iloc[i] - date_df['trading_day_close'].iloc[i])*lot_size)*(-1)

#         else:
#             date_df['MTM'].iloc[i]=0


#     print(f"MTM of strategy is {date_df['MTM'].sum()}")


    # # print(date_df)
    # date_df.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\date_df_monday_open.csv")

    # return 

# nifty_close(25)


#####################################################################################################################################

# df=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\nifty_exit_monday_open.csv",parse_dates=True, index_col=0)
# df=df[['Next_day','Short_Long','MTM']]
# df=df.reset_index(drop=True)

# df['portfolio']=0

# for i in range(len(df)):

#     if i==0:

#         df['portfolio'].iloc[i] = 100000 + df['MTM'].iloc[i]

#     else:
        
#         df['portfolio'].iloc[i] =  df['portfolio'].iloc[i-1] + df['MTM'].iloc[i]

# # print(df)
# plt.plot(df['portfolio'])
# plt.title(f"Exit at Monday Open (2007-2020)")
# plt.show()

# window = 252
# Roll_Max_portfolio = df['portfolio'].rolling(window, min_periods=1).max()
# Daily_Drawdown_portfolio = (df['portfolio']/Roll_Max_portfolio - 1)*100

# # Plot the results
# plt.figure(figsize=(20,8))
# plt.plot(Daily_Drawdown_portfolio, color="red", label="PORTFOLIO")
# plt.title("DRAWDOWN of Exit at Monday Open (2007-2020)")
# plt.legend()
# plt.show()

################################################################################################################

# data_1=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\nifty20072014.csv",parse_dates=True, index_col=0)
# data_1=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\nifty20152020.csv",parse_dates=True, index_col=0)

# date_data=data_1['Date'].unique()
# date_df=pd.DataFrame(date_data)
# date_df.columns=['Date']
# print(date_df)

# date_df.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\date_2015.csv")

import calendar
import datetime
# print(calendar.weekday(2016, 5, 15))


dt = datetime.datetime(2019-7-20)
print(dt)