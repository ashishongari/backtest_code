import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import pandas_datareader as pdr
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
import talib
import seaborn as sns
from scipy.stats import norm
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split 
from sklearn.metrics import mean_squared_error, r2_score
from sklearn import metrics
import scipy.optimize as opt
from sklearn.metrics import confusion_matrix 
from sklearn.metrics import accuracy_score
from sklearn import preprocessing
from sklearn.neighbors import KNeighborsClassifier
import time
import threading
from time import perf_counter
import concurrent.futures
import multiprocessing


start=perf_counter()

def nse(symbol_1):
    nifty=get_history(symbol_1, start=date(2010,1,1), end=date.today(), index=True)['Close']
    print(nifty)

def nsebank(symbol_2):
    nifty_bank=get_history(symbol_2, start=date(2010,1,1), end=date.today(), index=True)['Close']
    print(nifty_bank)

if __name__ == "__main__": 

    p1 = multiprocessing.Process(target=nse, args=('NIFTY50', )) 
    p2 = multiprocessing.Process(target=nsebank, args=('NIFTY BANK', )) 
  
    p1.start() 
    p2.start() 

    p1.join() 
    p2.join() 
    
    finish=time.perf_counter()
    print(f'finished in {round(finish-start,2)} seconds\n')


# def normal_run():
    
#     start=time.perf_counter()

#     nifty_index=get_history('NIFTY 50', start=date(2010,1,1), end=date.today(), index=True)['Close']
#     vix_index=get_history('NIFTY BANK', start=date(2010,1,1), end=date.today(), index=True)['Close']

#     print(nifty_index)
#     print(vix_index)
        
#     finish=time.perf_counter()  

#     print(f'finished in {round(finish-start,2)} second(s)')

#     return

# normal_run()