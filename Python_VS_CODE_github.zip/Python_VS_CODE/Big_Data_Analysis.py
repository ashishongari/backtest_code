import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import pandas_datareader as pdr
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
import talib
import seaborn as sns
from statsmodels.tsa.stattools import adfuller
import statsmodels.api as sm  
from nsetools import Nse 
import datetime 
from datetime import datetime, timedelta

def big_data_function(index_of_stock):
    
    big_data=pd.read_csv(r'C:\Users\DeepakShenoy\Documents\60min.csv')

    big_data_df=big_data.copy()
    big_data_df=big_data_df.drop('symbol', axis='columns')
    big_data_df=big_data_df.set_index('long_name')

    stock_list=list(big_data_df.index.unique())
    stock_list_df=pd.DataFrame(stock_list)

    name=stock_list[index_of_stock]
    big_data_df_stock=big_data_df.loc[name]
    big_data_df_stock=big_data_df_stock[['date','time','close']]

    big_data_df_stock['Date_time']=pd.to_datetime(big_data_df_stock['date'] +' '+ big_data_df_stock['time'])
    big_data_df_stock=big_data_df_stock[['Date_time','close']]
    big_data_df_stock=big_data_df_stock.reset_index(drop=True)
    print(big_data_df_stock)

    print(big_data_df_stock.dtypes)
    sns.set(style='whitegrid')
    plt.plot(big_data_df_stock['Date_time'].iloc[1:] ,big_data_df_stock['close'].iloc[1:], color='green')
    plt.title(name)
    plt.show()

    # big_data_df_stock.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\big_data_df_stock_bse_teck_index.csv")

    return

big_data_function(21)
