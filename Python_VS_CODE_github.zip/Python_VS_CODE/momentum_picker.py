import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import pandas_datareader as pdr
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
from nsetools import Nse
from statsmodels.tsa.stattools import adfuller
import statsmodels.api as sm  
from nsetools import Nse 
from datetime import datetime, timedelta
from nsetools import Nse 
from nsepy.history import get_price_list
import datetime
import pandas_datareader.data as web


def momentum_pick(rolling_day):

    df=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\historical_price_feb_2021.csv", index_col=0)
    df=df.replace(np.nan,0)
    eod_return_df=df.pct_change().mul(100)
    
    rolling_return_df =eod_return_df.rolling(window=rolling_day).sum()
    momentum_stock = pd.DataFrame(rolling_return_df.iloc[-1])
    momentum_stock=momentum_stock.sort_values(by=['12-02-2021'], ascending=False)

    print(momentum_stock.head(50))

momentum_pick(30)