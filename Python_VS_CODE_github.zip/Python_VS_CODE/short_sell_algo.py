import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import pandas_datareader as pdr
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
import talib
import seaborn as sns
from statsmodels.tsa.stattools import adfuller
import statsmodels.api as sm  
from nsetools import Nse 
import datetime 
from datetime import datetime, timedelta
from nsetools import Nse 


# def simple_short_sell(ticker):
    
#     nse = Nse()
#     lot_size_dict=nse.get_fno_lot_sizes()

#     ticker='FEDERALBNK'

#     lot_size=lot_size_dict[ticker]

#     data = pdr.get_data_yahoo('FEDERALBNK.NS', start=datetime.datetime(2011, 1, 1), end=datetime.datetime.today())['Close']
#     data=pd.DataFrame(data)

#     data['prev_Close']=data['Close'].shift(1)
#     data['running_min']=data['Close'].expanding().max()
#     data['point_change']=data['Close'].sub(data['prev_Close'])

#     data['Change']=((data['Close'].div(data['running_min']))-1)*100
#     data['short_sell']=-50.0
#     data['exit']=-40.0

#     plt.figure(figsize=(18,8))
#     data['Change'].plot()
#     data['short_sell'].plot()
#     data['exit'].plot()

#     data['short_sell_signal']=data['Change']<-50.0
#     data['exit_signal']=data['Change']>-40.0
#     data['signal']=0


#     for i in range(len(data)):
        
#         if i==0:
#             data['signal'].iloc[i]='No_Position'
            
#         elif data['short_sell_signal'].iloc[i]==True and data['exit_signal'].iloc[i]==False:
            
#             data['signal'].iloc[i]='Short_sell'
            
#         else:
            
#             data['signal'].iloc[i]='No_Position'  


#     data['MTM']=0

#     data['signal']=data['signal'].shift(1)

#     for i in range(len(data)):
        
#         if i==0:
            
#             data['MTM']=0
        
#         elif data['signal'].iloc[i]=='Short_sell':
            
#             data['MTM'].iloc[i]=(-data['point_change'].iloc[i]*lot_size)-5
            
#         else:
            
#             data['MTM'].iloc[i]=0
            
#     data['Portfolio_Margin']=0

#     for i in range(len(data)):
        
#         if i==0:
#             data['Portfolio_Margin'].iloc[i]=8_00_000
            
#         else:
            
#             data['Portfolio_Margin'].iloc[i]=data['Portfolio_Margin'].iloc[i-1]+data['MTM'].iloc[i-1]
        
#     plt.figure(figsize=(18,8))
#     plt.plot(data['Portfolio_Margin'], color='green')
#     plt.title("Equity Curve")
#     plt.show()

#     return

# simple_short_sell()

# def big_data_function():
    
#     big_data=pd.read_csv(r'C:\Users\DeepakShenoy\Documents\60min.csv')
#     big_data_df=big_data.copy()
#     big_data_df=big_data_df.drop('symbol', axis='columns')
#     big_data_df=big_data_df.set_index('long_name')
    
#     return print(big_data_df.head())

# big_data_function()

# def advanced_short_sell():
    
#     ticker='FEDERALBNK'
#     nse = Nse()
#     lot_size_dict=nse.get_fno_lot_sizes()
#     lot_size=lot_size_dict[ticker]

#     data = pdr.get_data_yahoo('FEDERALBNK.NS', start=datetime.datetime(2011, 1, 1), end=datetime.datetime.today())['Close']
#     data=pd.DataFrame(data)

#     data['prev_Close']=data['Close'].shift(1)
#     data['running_min']=data['Close'].expanding().max()
#     data['point_change']=data['Close'].sub(data['prev_Close'])

#     data['Change']=((data['Close'].div(data['running_min']))-1)*100

#     data['short_sell']=-25.0

#     data['low']=data['Change'].expanding().min()

#     data['exit_curve']=data['low'] + (abs(data['low'])*0.20)

#     data['short_sell_signal']=data['Change']<-25.0

#     data['signal']=0

#     data['stop_signal']=data['Change']> data['exit_curve'] 

#     for i in range(len(data)):
        
#         if i==0:
            
#             data['signal'].iloc[i]='No_Position'
            
#         elif (data['short_sell_signal'].iloc[i]==True) and (data['stop_signal'].iloc[i]==False):
            
#             data['signal'].iloc[i]='Short_sell'
            
#         else:
            
#             data['signal'].iloc[i]='No_Position'  

#     data['signal']=data['signal'].shift(1)
            
#     data['MTM']=0

#     for i in range(len(data)):
        
#         if i==0:
            
#             data['MTM']=0
        
#         elif data['signal'].iloc[i]=='Short_sell':
            
#             data['MTM'].iloc[i]=(-data['point_change'].iloc[i]*lot_size)-5
            
#         else:
            
#             data['MTM'].iloc[i]=0
            
#     data['Portfolio_Margin']=0

#     for i in range(len(data)):
        
#         if i==0:
            
#             data['Portfolio_Margin'].iloc[i]=10_00_000
            
#         else:
            
#             data['Portfolio_Margin'].iloc[i]=data['Portfolio_Margin'].iloc[i-1]+data['MTM'].iloc[i]

        
#     plt.figure(figsize=(18,8))
#     plt.plot(data['Change'], label='Drawdown', color='black')
#     plt.plot(data['short_sell'], label='Short_sell_signal', color='green')
#     plt.plot(data['exit_curve'], label='Stop_loss_signal', color='red')
#     plt.title("Signal Chart")
#     plt.legend()
#     plt.show()

#     plt.figure(figsize=(18,8))
#     plt.plot(data['Portfolio_Margin'], color='green')
#     plt.title("Equity Curve")
#     plt.show()

#     return print(data.tail(5))

# advanced_short_sell()

nse = Nse()
lot_size_dict=nse.get_fno_lot_sizes()
df = pd.DataFrame(list(lot_size_dict.items()),columns = ['stock','lot'])
list_stock=np.array(df['stock'])
# print(list_stock[1])


def new_short_sell_algo(ticker):

    from nsetools import Nse 
    nse = Nse()
    lot_size_dict=nse.get_fno_lot_sizes()

    lot_size=lot_size_dict[ticker]

    end='.NS'
    symbol=ticker + end
    
    data = pdr.get_data_yahoo(symbol, start=datetime(2008, 1, 1), end=datetime.today())[['Open','Close']]

    data['prev_price']=data['Close'].shift(1)
    data['change']=data['Close'].sub(data['prev_price'])
    data['lot_size']=lot_size
    data['running_max']=data['Close'].expanding().max()
    data['short_sell']=data['running_max']*(0.80)
    data['bottom_price']=data['Close'].rolling(window=252).min()
    data['exit_price']=data['bottom_price'] + (abs(data['bottom_price'])*0.20)
    data=data.dropna()

    # plt.plot(data['Close'])
    # plt.plot(data['short_sell'])
    # plt.plot( data['exit_price'])
    # plt.show()

    data['sell_entry']=np.where( data['Close'] < data['short_sell'] ,1,0)
    data['sell_exit']=np.where(  data['Close'] > data['exit_price'] ,1,0)

    data['sell_position']=0

    for i in range(len(data)):
        
        if data['sell_entry'].iloc[i] ==1 and data['sell_exit'].iloc[i] ==0:
            
            data['sell_position'].iloc[i]='position_live'
                
        else :
            
            data['sell_position'].iloc[i]='no_position' 
    
    data['sell_position']=data['sell_position'].shift(1)

    data['MTM']=0

    for i in range(len(data)):

        if data['sell_position'].iloc[i]=='position_live':

            data['MTM'].iloc[i] = data['change'].iloc[i]*lot_size*(-1)
        else:

            data['MTM'].iloc[i] =0

    print(f" MTM of {ticker} is {data['MTM'].sum(axis=0)}")

    data['margin']=0

    for i in range(len(data)):

        if i==0:

            data['margin'].iloc[i]=10_00_000

        elif  data['sell_position'].iloc[i]=='position_live':

             data['margin'].iloc[i] = data['margin'].iloc[i-1] + data['MTM'].iloc[i]
        
        else:
             data['margin'].iloc[i] = data['margin'].iloc[i-1]


    # plt.plot(data['margin'])
    # plt.title(f"Equity Curve OF {ticker}")
    # plt.show()

    # data.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\bharti_short_sell.csv")

    return 

new_short_sell_algo(list_stock[10])

#################################################################################################################################3

