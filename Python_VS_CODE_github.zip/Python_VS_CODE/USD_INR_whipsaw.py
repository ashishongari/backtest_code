import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import pandas_datareader as pdr
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
import talib
import seaborn as sns
from statsmodels.tsa.stattools import adfuller
import statsmodels.api as sm  
from nsetools import Nse 
import datetime 
from datetime import datetime, timedelta

tick_data=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Intraday 1 Min Data\usdinr.csv",parse_dates=True, index_col=0)

tick_data_test=tick_data[['Date','Time','Close']]
tick_data_test=tick_data_test.dropna()
# print(tick_data_test)

tick_data_close=tick_data_test[['Date','Time','Close']]
date_date=tick_data_close['Date'].unique()
print(date_date)

whipsaw_stat_1=[]
whipsaw_stat_2=[]
whipsaw_stat_3=[]
whipsaw_stat_4=[]

whipsaw_data_1=[]
whipsaw_data_2=[]
whipsaw_data_3=[]
whipsaw_data_4=[]

date_array=[]

def whipsaw_data(day):
    
    for n in range(day):
        tick_data_test_test=tick_data_test.loc[tick_data_test['Date']==date_date[n]]
        date_num=date_array.append(date_date[n])

        data_1=180
        data_2=180
        data_3=len(tick_data_test_test)-2


        high_1=tick_data_test_test['Close'][0:data_1].max()
        low_1=tick_data_test_test['Close'][0:data_1].min()


        high_2=tick_data_test_test['Close'][data_1:data_2].max()
        low_2=tick_data_test_test['Close'][data_1:data_2].min()

        high_3=tick_data_test_test['Close'][data_2:data_3].max()
        low_3=tick_data_test_test['Close'][data_2:data_3].min()

    ##########################################################################
        if(high_2>high_1):

            whipsaw_stat_1.append("HH_1")
            diff=high_2-high_1
            whipsaw_data_1.append(diff)

        else:
            whipsaw_stat_1.append("NHH_1")
            whipsaw_data_1.append(0)


        if(high_3>high_2):

            whipsaw_stat_2.append("HH_2")
            diff=high_3-high_2
            whipsaw_data_2.append(diff)

        else:
            whipsaw_stat_2.append("NHH_2")
            whipsaw_data_2.append(0)

      ################################################################################    

        if(low_1>low_2):
            whipsaw_stat_3.append("LL_1")
            diff=low_1-low_2
            whipsaw_data_3.append(diff)

        else:
            whipsaw_stat_3.append("NLL_1")
            whipsaw_data_3.append(0)

        if(low_2>low_3):
            whipsaw_stat_4.append("LL_2")
            diff=low_2-low_3
            whipsaw_data_4.append(diff)

        else:
            whipsaw_stat_4.append("NLL_2")
            whipsaw_data_4.append(0)

    return
 
whipsaw_data(len(date_date))
    
date_array=pd.DataFrame(date_array)        
whipsaw_stat_1 =pd.DataFrame(whipsaw_stat_1)
whipsaw_stat_2 =pd.DataFrame(whipsaw_stat_2)
whipsaw_stat_3 =pd.DataFrame(whipsaw_stat_3)
whipsaw_stat_4 =pd.DataFrame(whipsaw_stat_4)

whipsaw_stat=pd.concat([date_array,whipsaw_stat_1,whipsaw_stat_3,whipsaw_stat_2,whipsaw_stat_4], axis=1)
whipsaw_stat.columns=('date','first_period_high_breach','first_period_low_breach','second_period_high_breach','second_period_low_breach')
whipsaw_stat['rank']=whipsaw_stat.sum(axis=1)
# print(whipsaw_stat)

date_array=pd.DataFrame(date_array)        
whipsaw_data_1 =pd.DataFrame(whipsaw_data_1)
whipsaw_data_2 =pd.DataFrame(whipsaw_data_2)
whipsaw_data_3 =pd.DataFrame(whipsaw_data_3)
whipsaw_data_4 =pd.DataFrame(whipsaw_data_4)

whipsaw_data=pd.concat([date_array,whipsaw_data_1,whipsaw_data_3,whipsaw_data_2,whipsaw_data_4], axis=1)
whipsaw_data.columns=('date','first_period_high_breach','first_period_low_breach','second_period_high_breach','second_period_low_breach')
# print(whipsaw_data)

whipsaw_stat['combination']=0

for i in range(len(whipsaw_stat)):
    
    whipsaw_stat['combination'].iloc[i] ={ whipsaw_stat['first_period_high_breach'].iloc[i], whipsaw_stat['first_period_low_breach'].iloc[i],
                   whipsaw_stat['second_period_high_breach'].iloc[i], whipsaw_stat['second_period_low_breach'].iloc[i] }

# print(whipsaw_stat)

print(f"Total Trading days are {len(date_date)} ")
print(whipsaw_stat['combination'].value_counts())
