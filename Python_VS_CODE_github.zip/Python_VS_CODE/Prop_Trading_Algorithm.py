import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
import matplotlib.pyplot as plt 
# import talib
import seaborn as sns
from statsmodels.tsa.stattools import adfuller
import statsmodels.api as sm  
from nsetools import Nse 
import datetime 
from datetime import datetime, timedelta
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report
from sklearn import preprocessing
from sklearn.neighbors import KNeighborsClassifier
from sklearn import metrics
import glob
from time import perf_counter
import time

def nifty_algorithm():
    
    data = yf.download(tickers=['^NSEI'], period="1y",interval="60m")
    data['EMA'] =data['Adj Close'].ewm(span=45, adjust=False).mean()
    print(data)
    print(f"NIFTY SPOT IS {data['Close'][-1]} AND LIVE EMA is {data['EMA'][-1]} AND SPREAD is {(data['Close'][-1]/data['EMA'][-1]-1)*100}")
    
    if data['Close'][-1] > data['EMA'][-1]:
        print("Long Signal")

    else:
        print("Short Signal")

    # plt.plot(data['Adj Close'], label='NIFTY 50 SPOT')
    # plt.plot(data['EMA'], color='black', label='NIFTY 50 EMA')
    # plt.title("NIFTY 50")
    # plt.legend()
    # plt.show()


def bank_nifty_algorithm():
    
    data = yf.download(tickers=['^NSEBANK'], period="1y",interval="60m")
    data['EMA'] =data['Adj Close'].ewm(span=50, adjust=False).mean()
    print(data)
    print(f"BANK NIFTY SPOT is {data['Close'][-1]} AND LIVE EMA is {data['EMA'][-1]} AND SPREAD is {(data['Close'][-1]/data['EMA'][-1]-1)*100}")
    
    if data['Close'][-1] > data['EMA'][-1]:
        print("Long Signal")
    
    else:
        print("Short Signal")

    # plt.plot(data['Adj Close'], label='NIFTY BANK SPOT')   
    # plt.plot(data['EMA'], color='black', label=' NIFTY BANK EMA')
    # plt.title("NIFTY BANK")
    # plt.legend()
    # plt.show()


# nifty_algorithm()
bank_nifty_algorithm()





