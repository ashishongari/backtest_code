import pandas as pd  
import numpy as np  
import matplotlib.pyplot as plt  
import pandas_datareader as pdr
import datetime 
import yfinance as yf
from nsepy import get_history
from datetime import date
import datetime as dt
from nsetools import Nse
import seaborn as sns
from scipy.stats import norm
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split 
from sklearn.metrics import mean_squared_error, r2_score
from sklearn import metrics
import scipy.optimize as opt
from sklearn.metrics import confusion_matrix 
from sklearn.metrics import accuracy_score
from sklearn import preprocessing
from sklearn.neighbors import KNeighborsClassifier

tick_data=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\nifty20152020.csv",parse_dates=True, index_col=0)
tick_data_test=tick_data[['Date','Time','Close']]
tick_data_test=tick_data_test.dropna()
tick_data_close=tick_data_test[['Date','Time','Close']]
date_date=tick_data_close['Date'].unique()

date_array=[]
first_hour_high_array=[]
first_hour_low_array=[]

###############################################################
candle_time=30
n=15
###############################################################

def stop_loss(candle,num_of_day):
    
    for i in range(num_of_day):
        
        tick_data_test_test=tick_data_test.loc[tick_data_test['Date']==date_date[i]]

        first_hour_high=tick_data_test_test['Close'].iloc[0:candle].max()
        first_hour_high_array.append(first_hour_high)
        
        first_hour_low=tick_data_test_test['Close'].iloc[0:candle].min()
        first_hour_low_array.append(first_hour_low)
        
        date=date_date[i]
        date_array.append(date)

    return 
    
stop_loss(candle_time,len(date_date)-1)

date_array=pd.DataFrame(date_array)
first_hour_high_array=pd.DataFrame(first_hour_high_array)
first_hour_low_array=pd.DataFrame(first_hour_low_array)

stop_loss_df=pd.concat([date_array,first_hour_high_array,first_hour_low_array],axis=1)
stop_loss_df.columns=['date','first_hour_high','first_hour_low']

stop_loss_df['range']=stop_loss_df['first_hour_high']-stop_loss_df['first_hour_low']
stop_loss_df['range_rolling_avg']=stop_loss_df['range'].rolling(window=n).mean()
stop_loss_df=stop_loss_df.dropna()

print(stop_loss_df)

tick_data=pd.read_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Trading Research\nifty20152020.csv",parse_dates=True, index_col=0)
tick_data_test=tick_data[['Date','Time','Close']]
tick_data_test=tick_data_test.dropna()
tick_data_close=tick_data_test[['Date','Time','Close']]

date_date=stop_loss_df['date'].unique()
print(len(date_date))

new_mtm=[]
date_array=[]

def nifty_intraday(lot_size, num_of_day,candle_time):
    
    for i in range(num_of_day):
        
        tick_data_test_test=tick_data_test.loc[tick_data_test['Date']==date_date[i]]
        tick_data_test_test =tick_data_test_test.reset_index(drop=True)
        
        date_new=date_date[i]
        date_array.append(date_new)

        first_hour_high=tick_data_test_test['Close'].iloc[0:candle_time].max()
        first_hour_low=tick_data_test_test['Close'].iloc[0:candle_time].min()

        live_data=tick_data_test_test['Close'].iloc[candle_time+1:len(tick_data_test_test)-1]
        live_data=pd.DataFrame(live_data)
        live_data['date']=date_new
        live_data['High']=first_hour_high
        live_data['Low']=first_hour_low

        live_data['prev_close']=live_data['Close'].shift(1)
        live_data['diff']=live_data['Close'].sub(live_data['prev_close'])
        
        stop_loss=stop_loss_df.loc[stop_loss_df['date'] ==date_date[i] ]['range_rolling_avg']
        
        live_data['stop_loss']=float(stop_loss)
        
        live_data['avg_long_stop']=live_data['Low'] + live_data['stop_loss']
        live_data['avg_short_stop']=live_data['High'] - live_data['stop_loss']
        
        avg_long_stop=live_data['avg_long_stop'].iloc[1]
        avg_long_stop=float(avg_long_stop)
        
        avg_short_stop=live_data['avg_short_stop'].iloc[1]
        avg_short_stop=float(avg_short_stop)
                
#         print(f" first_hour_high {first_hour_high}")
#         print(f"first_hour_low {first_hour_low}")
#         print(f"avg_long_stop {avg_long_stop} ")
#         print(f" avg_short_stop {avg_short_stop}")
        
        if avg_short_stop < first_hour_low:
            
            live_data['long_stop']=float(first_hour_low)
            
        else:
              live_data['long_stop']=float(avg_short_stop)
                
        
        if avg_long_stop > first_hour_high:
            
            live_data['short_stop']=float(first_hour_high)
            
        else:
              live_data['short_stop']=float(avg_long_stop)
                
            
        live_data['signal_buy_entry']=np.where( live_data['Close'] > live_data['High'] ,1,0)
        live_data['buy_exit']=np.where( live_data['Close'] < live_data['long_stop'] ,1,0)
        live_data['buy_position']=0
        live_data=live_data.dropna()

        for i in range(len(live_data)-1):

            if (live_data['signal_buy_entry'].iloc[i] ==0 and live_data['buy_exit'].iloc[i] ==1) and (live_data['buy_position'].iloc[i-1] =='postion_live'):

                live_data['buy_position'].iloc[i]='no_position'

            elif (live_data['signal_buy_entry'].iloc[i] ==1 and live_data['buy_exit'].iloc[i] ==0) or (live_data['buy_position'].iloc[i-1] =='postion_live') :

                live_data['buy_position'].iloc[i]='postion_live'

            else :

                live_data['buy_position'].iloc[i]='no_position'


        live_data['signal_sell_entry']=np.where(live_data['Close'] < live_data['Low'],1,0)
        live_data['sell_exit']=np.where( live_data['Close'] >  live_data['short_stop'] ,1,0)
        live_data['sell_position']=0
        
        for i in range(len(live_data)-1):

            if (live_data['signal_sell_entry'].iloc[i] ==0 and live_data['sell_exit'].iloc[i] ==1) and (live_data['sell_position'].iloc[i-1] =='postion_live'):

                live_data['sell_position'].iloc[i]='no_position'

            elif (live_data['signal_sell_entry'].iloc[i] ==1 and live_data['sell_exit'].iloc[i] ==0) or (live_data['sell_position'].iloc[i-1] =='postion_live') :

                live_data['sell_position'].iloc[i]='postion_live'

            else :

                live_data['sell_position'].iloc[i]='no_position'

        
        live_data['buy_signal']=np.where(live_data['buy_position'] =='postion_live', 1 , 0)
        live_data['sell_signal']=np.where(live_data['sell_position'] =='postion_live', -1 , 0)
        live_data['signal']= live_data['buy_signal'].add(live_data['sell_signal'])
        
        live_data['signal']=live_data['signal'].shift(1)
        live_data=live_data.dropna()

        live_data['MTM']=0

        for i in range(len(live_data)-1):

            if live_data['signal'].iloc[i] ==1:

                live_data['MTM'].iloc[i] =(live_data['diff'].iloc[i]*lot_size)

            elif live_data['signal'].iloc[i] ==-1:

                live_data['MTM'].iloc[i] =(-1*live_data['diff'].iloc[i]*lot_size)

            else:

                live_data['MTM'].iloc[i] =0

        mtm=live_data['MTM'].sum(axis=0)
        new_mtm.append(mtm)

#         plt.figure(figsize=(18,8))
#         plt.plot(live_data['Close'], label='Spot')
        
#         plt.plot(live_data['long_stop'], color='black', label='long_stop')
#         plt.plot(live_data['short_stop'], color='yellow', label='short_stop')
        
#         plt.plot(live_data['High'], color='green', label='High')
#         plt.plot(live_data['Low'], color='red', label='Low')
        
#         plt.plot(live_data['avg_long_stop'], color='black', label='avg_long_stop')
#         plt.plot(live_data['avg_short_stop'], color='grey', label='avg_short_stop')
        
#         plt.legend()
        
#         live_data.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\live_data.csv")
         
    return  
    
nifty_intraday(75,len(date_date)-2, candle_time)


mtm_array_df=pd.DataFrame(new_mtm)
date_array_df=pd.DataFrame(date_date)

backtest_df=pd.concat([date_array_df,mtm_array_df], axis=1)
backtest_df.columns=['date','daily_mtm_per_lot']
backtest_df=backtest_df.dropna()

backtest_df =backtest_df.reset_index(drop=True)
backtest_df.set_index(['date'], inplace=True)
backtest_df =backtest_df.dropna()
print(backtest_df)

print(backtest_df['daily_mtm_per_lot'].sum())

# backtest_df.to_csv(r"C:\Users\DeepakShenoy\Desktop\Quantitative Research\Short_Sell\nifty_breakout_20152020_30min_15davg.csv")